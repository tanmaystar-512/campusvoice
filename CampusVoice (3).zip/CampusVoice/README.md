# CampusVoice

**Anonymous Student Issue Reporting & Class-Level Verification System**

- **Student:** Yash Raj
- **Roll Number:** 24EARAD183
- **Branch:** B.Tech Artificial Intelligence & Data Science (Section C)
- **College:** Arya College of Engineering & IT, Jaipur
- **Affiliation:** Rajasthan Technical University (RTU), Kota
- **Role:** Front End Leader
- **Development Stage:** Front-End Swing Prototype (In-Memory Architecture)

---

## 1. System Overview

CampusVoice provides a structured, privacy-oriented desktop platform where students can anonymously report campus issues and allow their class cohort to verify the problem via single-use tokens before escalating to administration.

### Core Modules Implemented
1. **Dual-Role Authentication Portal (`LoginFrame`):** Distinct partitioned tabs for Student Portal (ID: `183` / Pass: `1234`) and Administrator Portal (Username: `admin` / Pass: `admin123`).
2. **Student Dashboard (`StudentDashboard`):** Navigation hub with student profile badge, daily token status card, live issue metrics, and recent issues table.
3. **Anonymous Issue Reporting (`IssueReportFrame`):** Category picker, title & description inputs, supporting evidence file chooser (`JFileChooser`), and automatic `CV-XXXX` ID generation.
4. **Class-Level Verification (`VerificationFrame`):** Daily token validation (`CV1832026`), single-use enforcement, anonymous voting (`Frequently`, `Sometimes`, `Never`), and real-time aggregated class verification percentage calculation.
5. **Issue Status Tracker (`TrackingFrame`):** Lookup by Issue ID (`CV-4821`), visual lifecycle status badge, metadata, and voting breakdown.
6. **Post-Resolution Re-Verification (`ReVerificationFrame`):** Accountability feedback loop for resolved issues with auto-reopen triggers if issues persist.
7. **Administrative Review (`AdminDashboard`):** Full departmental management dashboard accessible directly via Admin Login with category/status filters, metric counters, and status updates.

---

## 2. Quick Demo Credentials & Keys

| Portal / Role | Username / ID | Password | Destination Screen |
| :--- | :--- | :--- | :--- |
| **Student Portal** | `183` | `1234` | [`StudentDashboard`](file:///c:/Users/yashk/OneDrive/Desktop/CampusVoice/src/campusvoice/ui/StudentDashboard.java) |
| **Administrator Portal** | `admin` | `admin123` | [`AdminDashboard`](file:///c:/Users/yashk/OneDrive/Desktop/CampusVoice/src/campusvoice/ui/AdminDashboard.java) |
| **Daily Voting Token** | `CV1832026` | - | Single-use class verification token |
| **Pre-Seeded Issue IDs**| `CV-1847`, `CV-4821`, `CV-7392` | - | Pre-seeded for immediate live testing |

---

## 3. How to Run

### Option A: From IntelliJ IDEA
1. Open the project in IntelliJ IDEA (`File` -> `Open` -> select `CampusVoice` folder).
2. Navigate to `src/campusvoice/Main.java`.
3. Right-click and choose **Run 'Main.main()'** (or click the Green Run Play button).

### Option B: Quick Launcher Scripts
- **Modern Web UI (HTML/CSS/JS):** Double-click [`run_web.bat`](file:///c:/Users/yashk/OneDrive/Desktop/CampusVoice/run_web.bat) or open [`web/index.html`](file:///c:/Users/yashk/OneDrive/Desktop/CampusVoice/web/index.html) in your browser.
- **Java Swing Desktop UI:** Double-click [`run.bat`](file:///c:/Users/yashk/OneDrive/Desktop/CampusVoice/run.bat).

### Option C: Command Line
```powershell
# 1. Launch Modern HTML/CSS/JS Web App via embedded Java Server:
java -cp out campusvoice.WebServer

# 2. Launch Java Swing Desktop UI:
java -cp out campusvoice.Main

# 3. Run Automated Verification Tests:
java -cp out campusvoice.TestSuite
```

---

## 4. 8-Point Demonstration Walkthrough (Viva / Evaluation)

- **Test 1 (Login):** Enter ID `183`, Password `1234` -> Dashboard opens. Try empty fields or wrong password to demonstrate validation errors.
- **Test 2 (Report Issue):** Click *Report Issue* -> Select *Laboratory*, enter Title and Description, optionally attach evidence -> Submit -> Notice generated ID (e.g. `CV-5829`) and live update on Dashboard table.
- **Test 3 (Verify Issue):** Click *Verify Issue* -> Use token `CV1832026` -> Select an option (`Frequently`) -> Submit -> Notice vote counts, participation %, and outcome change to *CLASS VERIFIED*.
- **Test 4 (Token Security):** Try voting again with `CV1832026` -> System shows *"This token has already been used"*. Try typing an invalid token -> Shows *"Invalid or expired token"*.
- **Test 5 (Track Valid Issue):** Click *Track Issue* -> Enter `CV-4821` -> Displays category, reported date, full description, and voting statistics.
- **Test 6 (Track Invalid ID):** Enter `CV-9999` -> System displays *"Issue not found. Please check your Issue ID"*.
- **Test 7 (Re-Verification):** Click *Re-verification* -> Select resolved issue `CV-7392` -> Select *"Still Facing Problem"* -> Submit -> System detects recurring dissatisfaction and flags the issue for reopening.
- **Test 8 (Logout):** Click *Logout* -> Prompts confirmation and cleanly returns to Login.
