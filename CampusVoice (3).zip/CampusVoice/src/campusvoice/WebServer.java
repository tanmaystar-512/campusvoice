package campusvoice;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;

/**
 * Built-in Lightweight HTTP Web Server for CampusVoice.
 * Serves the modern HTML5/CSS3/JavaScript frontend on http://localhost:8080
 * with zero external dependencies, using Java's built-in HttpServer.
 */
public class WebServer {

    private static final int PORT = 8080;
    private static final String WEB_DIR = "web";

    public static void main(String[] args) {
        try {
            HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
            server.createContext("/", new StaticFileHandler());
            server.setExecutor(null); // default executor
            server.start();

            System.out.println("======================================================");
            System.out.println("   CampusVoice Modern Web Application Running         ");
            System.out.println("   Lead: Yash Raj (24EARAD183) | Arya College (RTU)   ");
            System.out.println("======================================================");
            System.out.println("-> Server started on: http://localhost:" + PORT);
            System.out.println("-> Serving frontend from: ./" + WEB_DIR + "/");
            System.out.println("======================================================");

            // Automatically open user's default web browser
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                try {
                    Desktop.getDesktop().browse(new URI("http://localhost:" + PORT));
                    System.out.println("-> Web browser launched automatically.");
                } catch (Exception e) {
                    System.out.println("-> Open http://localhost:" + PORT + " manually in your web browser.");
                }
            } else {
                System.out.println("-> Open http://localhost:" + PORT + " in Chrome, Edge, or Firefox.");
            }

        } catch (IOException e) {
            System.err.println("Failed to start server: " + e.getMessage());
        }
    }

    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path == null || path.equals("/") || path.isEmpty()) {
                path = "/index.html";
            }

            File file = new File(WEB_DIR + path);
            if (!file.exists() || file.isDirectory()) {
                String notFound = "404 Not Found: " + path;
                exchange.sendResponseHeaders(404, notFound.length());
                OutputStream os = exchange.getResponseBody();
                os.write(notFound.getBytes());
                os.close();
                return;
            }

            String mime = getMimeType(file.getName());
            exchange.getResponseHeaders().set("Content-Type", mime);
            exchange.sendResponseHeaders(200, file.length());

            OutputStream os = exchange.getResponseBody();
            try (FileInputStream fis = new FileInputStream(file)) {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = fis.read(buffer)) > 0) {
                    os.write(buffer, 0, count);
                }
            }
            os.close();
        }

        private String getMimeType(String fileName) {
            if (fileName.endsWith(".html")) return "text/html; charset=UTF-8";
            if (fileName.endsWith(".css")) return "text/css; charset=UTF-8";
            if (fileName.endsWith(".js")) return "application/javascript; charset=UTF-8";
            if (fileName.endsWith(".json")) return "application/json; charset=UTF-8";
            if (fileName.endsWith(".png")) return "image/png";
            if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) return "image/jpeg";
            if (fileName.endsWith(".svg")) return "image/svg+xml";
            return "text/plain";
        }
    }
}
