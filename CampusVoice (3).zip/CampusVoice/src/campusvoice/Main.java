package campusvoice;

import campusvoice.ui.LoginFrame;

import javax.swing.*;

/**
 * Main application launcher for CampusVoice.
 * Anonymous Student Issue Reporting & Class-Level Verification System.
 * Developed by Yash Raj (Roll: 24EARAD183), Arya College of Engineering & IT, Jaipur.
 */
public class Main {
    public static void main(String[] args) {
        // Set native system look-and-feel for clean UI components on Windows
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Fallback to default Swing Look & Feel if system theme is unavailable
        }

        // Launch Login Frame on the Swing Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
