package campusvoice.ui;

import campusvoice.model.Issue;
import campusvoice.utils.DataStore;
import campusvoice.utils.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Modern Interactive ReVerificationFrame for CampusVoice.
 * Includes interactive selectable feedback cards, dynamic auto-reopen threshold alerts,
 * and immediate status escalation.
 */
public class ReVerificationFrame extends JFrame {

    private final StudentDashboard parentDashboard;

    private JComboBox<String> resolvedIssueSelector;
    private String selectedFeedbackOption = null;

    private JPanel resolvedCard;
    private JPanel partiallyCard;
    private JPanel stillFacingCard;
    private JTextArea feedbackNotesArea;
    private JPanel reopenNotice;

    public ReVerificationFrame(StudentDashboard parentDashboard) {
        this.parentDashboard = parentDashboard;

        setTitle("CampusVoice - Resolution Re-Verification");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 720);
        setMinimumSize(new Dimension(600, 600));
        setLocationRelativeTo(parentDashboard != null ? parentDashboard : null);

        initComponents();
    }

    private void initComponents() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UIUtils.COLOR_BG);

        // Header Panel with Gradient
        JPanel headerPanel = UIUtils.createHeader(
                "Post-Resolution Re-Verification",
                "Accountability Loop: Validate whether management's fix genuinely solved the issue."
        );
        rootPanel.add(headerPanel, BorderLayout.NORTH);

        // Content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.COLOR_BG);
        contentPanel.setBorder(new EmptyBorder(16, 24, 16, 24));

        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        // Issue Selector
        JLabel issueLabel = new JLabel("Select Resolved / Verified Issue *");
        issueLabel.setFont(UIUtils.FONT_BOLD);
        issueLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        issueLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        resolvedIssueSelector = new JComboBox<>();
        resolvedIssueSelector.setFont(UIUtils.FONT_REGULAR);
        resolvedIssueSelector.setBackground(Color.WHITE);
        resolvedIssueSelector.setAlignmentX(Component.LEFT_ALIGNMENT);
        resolvedIssueSelector.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        populateIssueList();

        // Interactive Feedback Cards
        JLabel questionLabel = new JLabel("Evaluation: \"How is the issue on campus after resolution?\" *");
        questionLabel.setFont(UIUtils.FONT_BOLD);
        questionLabel.setForeground(UIUtils.COLOR_PRIMARY);
        questionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel feedbackGrid = new JPanel(new GridLayout(1, 3, 12, 0));
        feedbackGrid.setOpaque(false);
        feedbackGrid.setAlignmentX(Component.LEFT_ALIGNMENT);
        feedbackGrid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));

        resolvedCard = createFeedbackCard("Resolved", "Completely fixed & working smoothly", UIUtils.COLOR_SUCCESS);
        partiallyCard = createFeedbackCard("Partially Resolved", "Minor improvement, but incomplete fix", UIUtils.COLOR_WARNING);
        stillFacingCard = createFeedbackCard("Still Facing Problem", "Issue persists / broken again", UIUtils.COLOR_DANGER);

        feedbackGrid.add(resolvedCard);
        feedbackGrid.add(partiallyCard);
        feedbackGrid.add(stillFacingCard);

        // Notes Area
        JLabel notesLabel = new JLabel("Additional Feedback / Inspection Notes (Optional)");
        notesLabel.setFont(UIUtils.FONT_BOLD);
        notesLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        notesLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        feedbackNotesArea = new JTextArea(3, 20);
        feedbackNotesArea.setFont(UIUtils.FONT_REGULAR);
        feedbackNotesArea.setLineWrap(true);
        feedbackNotesArea.setWrapStyleWord(true);
        feedbackNotesArea.setBorder(new EmptyBorder(6, 6, 6, 6));

        JScrollPane notesScroll = new JScrollPane(feedbackNotesArea);
        notesScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        notesScroll.setBorder(new LineBorder(UIUtils.COLOR_BORDER, 1, true));
        notesScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));

        // Auto-reopen Notice
        reopenNotice = new JPanel(new BorderLayout(5, 5));
        reopenNotice.setBackground(new Color(254, 242, 242));
        reopenNotice.setBorder(new CompoundBorder(
                new LineBorder(new Color(254, 202, 202), 1, true),
                new EmptyBorder(8, 12, 8, 12)
        ));
        reopenNotice.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel noticeLbl = new JLabel(
                "<html><b>Auto-Reopen Policy:</b> If student reports select <i>'Still Facing Problem'</i>, " +
                        "the issue is automatically reverted to <b>REOPENED</b> status for management escalation.</html>"
        );
        noticeLbl.setFont(UIUtils.FONT_SMALL);
        noticeLbl.setForeground(new Color(153, 27, 27));
        reopenNotice.add(noticeLbl, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);
        btnPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        JButton cancelBtn = UIUtils.createSecondaryButton("Cancel");
        JButton submitBtn = UIUtils.createPrimaryButton("Submit Feedback");

        cancelBtn.addActionListener(e -> dispose());
        submitBtn.addActionListener(e -> submitFeedback());

        btnPanel.add(cancelBtn);
        btnPanel.add(submitBtn);

        // Assemble
        card.add(issueLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(resolvedIssueSelector);
        card.add(Box.createVerticalStrut(16));
        card.add(questionLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(feedbackGrid);
        card.add(Box.createVerticalStrut(16));
        card.add(notesLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(notesScroll);
        card.add(Box.createVerticalStrut(14));
        card.add(reopenNotice);
        card.add(Box.createVerticalStrut(18));
        card.add(btnPanel);

        contentPanel.add(card);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        rootPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(rootPanel);
    }

    private JPanel createFeedbackCard(String title, String subtitle, Color color) {
        JPanel c = new JPanel(new BorderLayout(5, 4));
        c.setBackground(new Color(248, 250, 252));
        c.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                new EmptyBorder(10, 12, 10, 12)
        ));
        c.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(UIUtils.FONT_BOLD);
        titleLbl.setForeground(color);

        JLabel subLbl = new JLabel("<html>" + subtitle + "</html>");
        subLbl.setFont(UIUtils.FONT_SMALL);
        subLbl.setForeground(UIUtils.COLOR_TEXT_MUTED);

        c.add(titleLbl, BorderLayout.NORTH);
        c.add(subLbl, BorderLayout.CENTER);

        c.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectFeedbackOption(title);
            }
        });
        return c;
    }

    private void selectFeedbackOption(String option) {
        this.selectedFeedbackOption = option;

        resetCardStyle(resolvedCard, "Resolved".equals(option), UIUtils.COLOR_SUCCESS);
        resetCardStyle(partiallyCard, "Partially Resolved".equals(option), UIUtils.COLOR_WARNING);
        resetCardStyle(stillFacingCard, "Still Facing Problem".equals(option), UIUtils.COLOR_DANGER);
    }

    private void resetCardStyle(JPanel c, boolean isSelected, Color activeColor) {
        if (isSelected) {
            c.setBackground(new Color(239, 246, 255));
            c.setBorder(new CompoundBorder(
                    new LineBorder(activeColor, 2, true),
                    new EmptyBorder(9, 11, 9, 11)
            ));
        } else {
            c.setBackground(new Color(248, 250, 252));
            c.setBorder(new CompoundBorder(
                    new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                    new EmptyBorder(10, 12, 10, 12)
            ));
        }
    }

    private void populateIssueList() {
        resolvedIssueSelector.removeAllItems();
        List<Issue> issues = DataStore.getInstance().getAllIssues();
        for (Issue issue : issues) {
            resolvedIssueSelector.addItem(issue.getIssueId() + " - [" + issue.getStatus() + "] " + issue.getTitle());
        }
    }

    private void submitFeedback() {
        String selectedItem = (String) resolvedIssueSelector.getSelectedItem();
        if (selectedItem == null) {
            JOptionPane.showMessageDialog(this, "No issue selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String issueId = selectedItem.split(" ")[0].trim();
        Issue issue = DataStore.getInstance().findIssueById(issueId);

        if (issue == null) {
            JOptionPane.showMessageDialog(this, "Issue not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (selectedFeedbackOption == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select one of the feedback cards above.",
                    "Input Required",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        issue.recordReVerification(selectedFeedbackOption);

        if (parentDashboard != null) {
            parentDashboard.refreshDashboardData();
        }

        String statusNotice = "RESOLVED".equalsIgnoreCase(issue.getStatus()) ?
                "Status remains RESOLVED." :
                "Status automatically escalated to REOPENED due to recurring issue feedback.";

        JOptionPane.showMessageDialog(
                this,
                "Feedback recorded successfully!\n\n" +
                        "Issue ID: " + issue.getIssueId() + "\n" +
                        "Feedback: " + selectedFeedbackOption + "\n" +
                        statusNotice,
                "Feedback Recorded",
                JOptionPane.INFORMATION_MESSAGE
        );

        this.dispose();
    }
}
