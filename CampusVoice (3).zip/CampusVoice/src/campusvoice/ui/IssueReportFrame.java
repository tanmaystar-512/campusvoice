package campusvoice.ui;

import campusvoice.model.Issue;
import campusvoice.utils.DataStore;
import campusvoice.utils.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Modern Interactive IssueReportFrame for CampusVoice.
 * Includes dynamic category hints, real-time description character counter,
 * interactive file attachment badge with 1-click removal, and automatic CV-XXXX ID generation.
 */
public class IssueReportFrame extends JFrame {

    private final StudentDashboard parentDashboard;

    private JComboBox<String> categoryCombo;
    private JLabel categoryHintLabel;
    private JTextField titleField;
    private JTextArea descriptionArea;
    private JLabel charCountLabel;
    private JPanel fileBadgePanel;
    private JLabel selectedFileLabel;
    private JButton removeFileBtn;
    private String selectedEvidencePath = "";

    public IssueReportFrame(StudentDashboard parentDashboard) {
        this.parentDashboard = parentDashboard;

        setTitle("CampusVoice - Report Campus Issue (Confidential)");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(680, 740);
        setMinimumSize(new Dimension(580, 600));
        setLocationRelativeTo(parentDashboard != null ? parentDashboard : null);

        initComponents();
    }

    private void initComponents() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UIUtils.COLOR_BG);

        // Header Panel with Gradient
        JPanel headerPanel = UIUtils.createHeader(
                "Submit Anonymous Campus Issue",
                "Identity-Shielded Reporting: Your student identity is never attached or displayed."
        );
        rootPanel.add(headerPanel, BorderLayout.NORTH);

        // Form Card Panel
        JPanel formWrapper = new JPanel(new BorderLayout());
        formWrapper.setBackground(UIUtils.COLOR_BG);
        formWrapper.setBorder(new EmptyBorder(16, 24, 16, 24));

        JPanel formCard = UIUtils.createCardPanel();
        formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));

        // Category Field
        JLabel catLabel = new JLabel("Issue Category *");
        catLabel.setFont(UIUtils.FONT_BOLD);
        catLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        catLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        String[] categories = {
                "Classroom",
                "Faculty",
                "Laboratory",
                "Hostel",
                "Canteen",
                "Administration",
                "Other"
        };
        categoryCombo = new JComboBox<>(categories);
        categoryCombo.setFont(UIUtils.FONT_REGULAR);
        categoryCombo.setBackground(Color.WHITE);
        categoryCombo.setAlignmentX(Component.LEFT_ALIGNMENT);
        categoryCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        categoryHintLabel = new JLabel("Classroom: Report issues with projectors, AC units, furniture, or smart boards.");
        categoryHintLabel.setFont(UIUtils.FONT_SMALL);
        categoryHintLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        categoryHintLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        categoryCombo.addActionListener(e -> updateCategoryHint());

        // Title Field
        JLabel titleLabel = new JLabel("Issue Title / Subject *");
        titleLabel.setFont(UIUtils.FONT_BOLD);
        titleLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        titleField = UIUtils.createTextField();
        titleField.setAlignmentX(Component.LEFT_ALIGNMENT);
        titleField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        // Description Field with Live Character Counter
        JPanel descHeaderRow = new JPanel(new BorderLayout());
        descHeaderRow.setOpaque(false);
        descHeaderRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        descHeaderRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));

        JLabel descLabel = new JLabel("Detailed Description *");
        descLabel.setFont(UIUtils.FONT_BOLD);
        descLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);

        charCountLabel = new JLabel("0 / 500 characters");
        charCountLabel.setFont(UIUtils.FONT_SMALL);
        charCountLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        descHeaderRow.add(descLabel, BorderLayout.WEST);
        descHeaderRow.add(charCountLabel, BorderLayout.EAST);

        descriptionArea = new JTextArea(5, 20);
        descriptionArea.setFont(UIUtils.FONT_REGULAR);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setBorder(new EmptyBorder(8, 8, 8, 8));

        descriptionArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateCharCount(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateCharCount(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateCharCount(); }

            private void updateCharCount() {
                int len = descriptionArea.getText().length();
                charCountLabel.setText(len + " / 500 characters");
                if (len > 500) {
                    charCountLabel.setForeground(UIUtils.COLOR_DANGER);
                } else {
                    charCountLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
                }
            }
        });

        JScrollPane descScroll = new JScrollPane(descriptionArea);
        descScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        descScroll.setBorder(new LineBorder(UIUtils.COLOR_BORDER, 1, true));
        descScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));

        // Evidence Attachment Panel
        JLabel evidenceLabel = new JLabel("Supporting Evidence (Optional Image / Log)");
        evidenceLabel.setFont(UIUtils.FONT_BOLD);
        evidenceLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        evidenceLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        fileBadgePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        fileBadgePanel.setOpaque(false);
        fileBadgePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        fileBadgePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        JButton browseBtn = UIUtils.createSecondaryButton("Browse File...");
        browseBtn.addActionListener(e -> chooseEvidenceFile());

        selectedFileLabel = new JLabel("No file attached");
        selectedFileLabel.setFont(UIUtils.FONT_SMALL);
        selectedFileLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        removeFileBtn = new JButton("Remove [x]");
        removeFileBtn.setFont(UIUtils.FONT_SMALL);
        removeFileBtn.setForeground(UIUtils.COLOR_DANGER);
        removeFileBtn.setVisible(false);
        removeFileBtn.addActionListener(e -> clearEvidenceFile());

        fileBadgePanel.add(browseBtn);
        fileBadgePanel.add(selectedFileLabel);
        fileBadgePanel.add(removeFileBtn);

        // Buttons Panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);
        btnPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));

        JButton cancelBtn = UIUtils.createSecondaryButton("Cancel");
        JButton clearBtn = UIUtils.createSecondaryButton("Clear Form");
        JButton submitBtn = UIUtils.createPrimaryButton("Submit Issue (Get CV-ID)");

        cancelBtn.addActionListener(e -> dispose());
        clearBtn.addActionListener(e -> clearForm());
        submitBtn.addActionListener(e -> submitIssue());

        btnPanel.add(cancelBtn);
        btnPanel.add(clearBtn);
        btnPanel.add(submitBtn);

        // Assemble Form
        formCard.add(catLabel);
        formCard.add(Box.createVerticalStrut(5));
        formCard.add(categoryCombo);
        formCard.add(Box.createVerticalStrut(4));
        formCard.add(categoryHintLabel);
        formCard.add(Box.createVerticalStrut(14));

        formCard.add(titleLabel);
        formCard.add(Box.createVerticalStrut(5));
        formCard.add(titleField);
        formCard.add(Box.createVerticalStrut(14));

        formCard.add(descHeaderRow);
        formCard.add(Box.createVerticalStrut(5));
        formCard.add(descScroll);
        formCard.add(Box.createVerticalStrut(14));

        formCard.add(evidenceLabel);
        formCard.add(Box.createVerticalStrut(5));
        formCard.add(fileBadgePanel);
        formCard.add(Box.createVerticalStrut(20));

        formCard.add(btnPanel);

        formWrapper.add(formCard, BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(formWrapper);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        rootPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(rootPanel);
    }

    private void updateCategoryHint() {
        String cat = (String) categoryCombo.getSelectedItem();
        if ("Classroom".equals(cat)) {
            categoryHintLabel.setText("Classroom: Report issues with projectors, AC units, furniture, or smart boards.");
        } else if ("Laboratory".equals(cat)) {
            categoryHintLabel.setText("Laboratory: Report issues with GPU workstations, compiler software, instruments, or network.");
        } else if ("Faculty".equals(cat)) {
            categoryHintLabel.setText("Faculty: Confidential reporting on lecture scheduling, coverage, or academic guidance.");
        } else if ("Hostel".equals(cat)) {
            categoryHintLabel.setText("Hostel: Report issues with electricity, water supply, room maintenance, or mess.");
        } else if ("Canteen".equals(cat)) {
            categoryHintLabel.setText("Canteen: Report issues with food hygiene, pricing, digital payment scanner, or seating.");
        } else if ("Administration".equals(cat)) {
            categoryHintLabel.setText("Administration: Report fee counters, document issuance, scholarship desk, or transport delays.");
        } else {
            categoryHintLabel.setText("Other: Report any internal college facility concern.");
        }
    }

    private void chooseEvidenceFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Supporting Evidence File");
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            selectedEvidencePath = selectedFile.getName();
            selectedFileLabel.setText(selectedFile.getName() + " (" + (selectedFile.length() / 1024) + " KB)");
            selectedFileLabel.setForeground(UIUtils.COLOR_SUCCESS);
            removeFileBtn.setVisible(true);
        }
    }

    private void clearEvidenceFile() {
        selectedEvidencePath = "";
        selectedFileLabel.setText("No file attached");
        selectedFileLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        removeFileBtn.setVisible(false);
    }

    private void clearForm() {
        categoryCombo.setSelectedIndex(0);
        titleField.setText("");
        descriptionArea.setText("");
        clearEvidenceFile();
        titleField.requestFocus();
    }

    private void submitIssue() {
        String title = titleField.getText().trim();
        String description = descriptionArea.getText().trim();
        String category = (String) categoryCombo.getSelectedItem();

        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Issue Title.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            titleField.requestFocus();
            return;
        }

        if (description.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter issue description.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            descriptionArea.requestFocus();
            return;
        }

        DataStore store = DataStore.getInstance();
        String generatedId = store.generateIssueId();
        String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        Issue newIssue = new Issue(
                generatedId,
                category,
                title,
                description,
                selectedEvidencePath,
                currentDate,
                "REPORTED"
        );

        store.addIssue(newIssue);

        if (parentDashboard != null) {
            parentDashboard.refreshDashboardData();
        }

        int option = JOptionPane.showOptionDialog(
                this,
                "Issue submitted successfully!\n\n" +
                        "Your Unique Issue ID:  " + generatedId + "\n\n" +
                        "• Class-level voting is now open for your cohort.\n" +
                        "• You can track progress anytime with this Issue ID.",
                "Issue Submitted",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                new String[]{"Track This Issue Now", "Done"},
                "Track This Issue Now"
        );

        this.dispose();

        if (option == 0) {
            TrackingFrame trackingFrame = new TrackingFrame(parentDashboard);
            trackingFrame.setPrefilledIssueId(generatedId);
            trackingFrame.setVisible(true);
        }
    }
}
