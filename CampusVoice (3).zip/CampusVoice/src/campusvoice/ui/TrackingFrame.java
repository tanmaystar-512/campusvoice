package campusvoice.ui;

import campusvoice.model.Issue;
import campusvoice.utils.DataStore;
import campusvoice.utils.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

/**
 * Modern Interactive TrackingFrame for CampusVoice.
 * Includes a visual 4-step milestone progression stepper, 1-click quick-pick issue pills,
 * copy-to-clipboard button, and interactive voting analytics.
 */
public class TrackingFrame extends JFrame {

    private final StudentDashboard parentDashboard;

    private JTextField searchField;
    private JPanel stepperPanel;
    private JLabel step1Label;
    private JLabel step2Label;
    private JLabel step3Label;
    private JLabel step4Label;

    // Details labels
    private JLabel issueIdLabel;
    private JLabel categoryLabel;
    private JLabel titleLabel;
    private JLabel dateLabel;
    private JLabel statusBadge;
    private JTextArea descArea;
    private JLabel evidenceLabel;
    private JProgressBar voteProgressBar;
    private JLabel votesSummaryLabel;

    public TrackingFrame(StudentDashboard parentDashboard) {
        this.parentDashboard = parentDashboard;

        setTitle("CampusVoice - Issue Status Tracker & Milestone Pipeline");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(780, 760);
        setMinimumSize(new Dimension(680, 620));
        setLocationRelativeTo(parentDashboard != null ? parentDashboard : null);

        initComponents();
    }

    public void setPrefilledIssueId(String issueId) {
        if (issueId != null && searchField != null) {
            searchField.setText(issueId);
            performSearch();
        }
    }

    private void initComponents() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UIUtils.COLOR_BG);

        // Header Panel with Gradient
        JPanel headerPanel = UIUtils.createHeader(
                "Track Campus Issue Progress",
                "Lifecycle Pipeline: Visual milestone progression from initial reporting to resolution."
        );
        rootPanel.add(headerPanel, BorderLayout.NORTH);

        // Content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.COLOR_BG);
        contentPanel.setBorder(new EmptyBorder(16, 24, 16, 24));

        // Search & Quick-Pills Card
        JPanel searchCard = UIUtils.createCardPanel();
        searchCard.setLayout(new BoxLayout(searchCard, BoxLayout.Y_AXIS));

        JPanel searchRow = new JPanel(new BorderLayout(10, 0));
        searchRow.setOpaque(false);

        JLabel searchPrompt = new JLabel("Issue ID: ");
        searchPrompt.setFont(UIUtils.FONT_BOLD);
        searchPrompt.setForeground(UIUtils.COLOR_TEXT_MAIN);

        searchField = UIUtils.createTextField();
        searchField.setFont(UIUtils.FONT_MONO);
        searchField.setText("CV-4821");

        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performSearch();
                }
            }
        });

        JButton searchBtn = UIUtils.createPrimaryButton("Track Issue");
        searchBtn.addActionListener(e -> performSearch());

        searchRow.add(searchPrompt, BorderLayout.WEST);
        searchRow.add(searchField, BorderLayout.CENTER);
        searchRow.add(searchBtn, BorderLayout.EAST);

        // Quick-Pick Buttons Row
        JPanel quickPickRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        quickPickRow.setOpaque(false);
        quickPickRow.setBorder(new EmptyBorder(10, 0, 0, 0));

        JLabel quickLabel = new JLabel("Quick Sample Issues:");
        quickLabel.setFont(UIUtils.FONT_SMALL);
        quickLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        quickPickRow.add(quickLabel);

        List<Issue> issues = DataStore.getInstance().getAllIssues();
        for (int i = 0; i < Math.min(4, issues.size()); i++) {
            Issue issue = issues.get(i);
            JButton pillBtn = new JButton(issue.getIssueId());
            pillBtn.setFont(UIUtils.FONT_SMALL);
            pillBtn.setBackground(new Color(241, 245, 249));
            pillBtn.setForeground(UIUtils.COLOR_PRIMARY);
            pillBtn.setBorder(new CompoundBorder(
                    new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                    new EmptyBorder(3, 8, 3, 8)
            ));
            pillBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            pillBtn.addActionListener(e -> {
                searchField.setText(issue.getIssueId());
                performSearch();
            });
            quickPickRow.add(pillBtn);
        }

        searchCard.add(searchRow);
        searchCard.add(quickPickRow);

        contentPanel.add(searchCard);
        contentPanel.add(Box.createVerticalStrut(16));

        // Visual Milestone Stepper Card
        stepperPanel = createMilestoneStepper();
        contentPanel.add(stepperPanel);
        contentPanel.add(Box.createVerticalStrut(16));

        // Details Display Card
        JPanel detailsPanel = createDetailsCard();
        contentPanel.add(detailsPanel);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        rootPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(rootPanel);

        performSearch();
    }

    private JPanel createMilestoneStepper() {
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BorderLayout(10, 10));

        JLabel stepperTitle = new JLabel("Lifecycle Milestone Stepper");
        stepperTitle.setFont(UIUtils.FONT_SUBTITLE);
        stepperTitle.setForeground(UIUtils.COLOR_TEXT_MAIN);
        card.add(stepperTitle, BorderLayout.NORTH);

        JPanel stepsRow = new JPanel(new GridLayout(1, 4, 10, 0));
        stepsRow.setOpaque(false);

        step1Label = createStepIndicator("1. Reported", true);
        step2Label = createStepIndicator("2. Verifying", false);
        step3Label = createStepIndicator("3. Verified", false);
        step4Label = createStepIndicator("4. Resolved", false);

        stepsRow.add(step1Label);
        stepsRow.add(step2Label);
        stepsRow.add(step3Label);
        stepsRow.add(step4Label);

        card.add(stepsRow, BorderLayout.CENTER);
        return card;
    }

    private JLabel createStepIndicator(String text, boolean active) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setFont(UIUtils.FONT_BOLD);
        lbl.setOpaque(true);
        updateStepStyle(lbl, active);
        return lbl;
    }

    private void updateStepStyle(JLabel lbl, boolean active) {
        if (active) {
            lbl.setBackground(new Color(209, 250, 229));
            lbl.setForeground(new Color(4, 120, 87));
            lbl.setBorder(new CompoundBorder(
                    new LineBorder(new Color(5, 150, 105), 2, true),
                    new EmptyBorder(8, 10, 8, 10)
            ));
        } else {
            lbl.setBackground(new Color(241, 245, 249));
            lbl.setForeground(UIUtils.COLOR_TEXT_MUTED);
            lbl.setBorder(new CompoundBorder(
                    new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                    new EmptyBorder(8, 10, 8, 10)
            ));
        }
    }

    private JPanel createDetailsCard() {
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        // Top Row: ID + Copy Button + Status Badge
        JPanel topRow = new JPanel(new BorderLayout(10, 0));
        topRow.setOpaque(false);
        topRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel leftIdBlock = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftIdBlock.setOpaque(false);

        issueIdLabel = new JLabel("CV-XXXX");
        issueIdLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        issueIdLabel.setForeground(UIUtils.COLOR_PRIMARY);

        JButton copyBtn = new JButton("Copy ID");
        copyBtn.setFont(UIUtils.FONT_SMALL);
        copyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        copyBtn.addActionListener(e -> {
            StringSelection sel = new StringSelection(issueIdLabel.getText());
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel, null);
            JOptionPane.showMessageDialog(this, "Issue ID copied to clipboard!", "Copied", JOptionPane.INFORMATION_MESSAGE);
        });

        leftIdBlock.add(issueIdLabel);
        leftIdBlock.add(copyBtn);

        statusBadge = UIUtils.createStatusBadge("REPORTED");

        topRow.add(leftIdBlock, BorderLayout.WEST);
        topRow.add(statusBadge, BorderLayout.EAST);

        // Metadata
        JPanel metaRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        metaRow.setOpaque(false);
        metaRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        metaRow.setBorder(new EmptyBorder(8, 0, 8, 0));

        categoryLabel = new JLabel("Category: -");
        categoryLabel.setFont(UIUtils.FONT_REGULAR);
        categoryLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        dateLabel = new JLabel("Reported Date: -");
        dateLabel.setFont(UIUtils.FONT_REGULAR);
        dateLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        metaRow.add(categoryLabel);
        metaRow.add(dateLabel);

        // Title
        titleLabel = new JLabel("Issue Title");
        titleLabel.setFont(UIUtils.FONT_SUBTITLE);
        titleLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Description
        JLabel descTitle = new JLabel("Description:");
        descTitle.setFont(UIUtils.FONT_BOLD);
        descTitle.setForeground(UIUtils.COLOR_TEXT_MAIN);
        descTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        descArea = new JTextArea(4, 20);
        descArea.setFont(UIUtils.FONT_REGULAR);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setEditable(false);
        descArea.setBackground(new Color(248, 250, 252));
        descArea.setBorder(new EmptyBorder(8, 8, 8, 8));

        JScrollPane descScroll = new JScrollPane(descArea);
        descScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        descScroll.setBorder(new LineBorder(UIUtils.COLOR_BORDER, 1, true));
        descScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 85));

        // Evidence
        evidenceLabel = new JLabel("Evidence: None attached");
        evidenceLabel.setFont(UIUtils.FONT_SMALL);
        evidenceLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        evidenceLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Verification Tally Card with graphical bar
        JPanel tallyCard = new JPanel(new BorderLayout(8, 8));
        tallyCard.setBackground(new Color(241, 245, 249));
        tallyCard.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                new EmptyBorder(10, 14, 10, 14)
        ));
        tallyCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        tallyCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 75));

        votesSummaryLabel = new JLabel("Frequently: 0% | Sometimes: 0% | Never: 0% | Quorum: 0%");
        votesSummaryLabel.setFont(UIUtils.FONT_BOLD);
        votesSummaryLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);

        voteProgressBar = UIUtils.createProgressBar(0, UIUtils.COLOR_PRIMARY);

        tallyCard.add(votesSummaryLabel, BorderLayout.NORTH);
        tallyCard.add(voteProgressBar, BorderLayout.CENTER);

        card.add(topRow);
        card.add(metaRow);
        card.add(Box.createVerticalStrut(6));
        card.add(titleLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(descTitle);
        card.add(Box.createVerticalStrut(4));
        card.add(descScroll);
        card.add(Box.createVerticalStrut(10));
        card.add(evidenceLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(tallyCard);

        return card;
    }

    private void performSearch() {
        String query = searchField.getText().trim();

        if (query.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an Issue ID.", "Input Required", JOptionPane.WARNING_MESSAGE);
            searchField.requestFocus();
            return;
        }

        Issue issue = DataStore.getInstance().findIssueById(query);

        if (issue == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Issue not found. Please check your Issue ID.\n\nTip: Click any of the quick sample buttons above.",
                    "Not Found",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        issueIdLabel.setText(issue.getIssueId());
        categoryLabel.setText("Category: " + issue.getCategory());
        dateLabel.setText("Reported Date: " + issue.getDate());
        titleLabel.setText(issue.getTitle());
        descArea.setText(issue.getDescription());

        String evidence = issue.getEvidencePath();
        evidenceLabel.setText(evidence == null || evidence.trim().isEmpty() ?
                "Supporting Evidence: None attached" : "Supporting Evidence: " + evidence);

        int freqPct = (int) issue.getFrequentlyPercentage();
        int somePct = (int) issue.getSometimesPercentage();
        int neverPct = (int) issue.getNeverPercentage();
        int quorumPct = (int) issue.getParticipationRate();

        voteProgressBar.setValue(freqPct + somePct);
        votesSummaryLabel.setText(String.format(
                "Frequently: %d%% (%d) | Sometimes: %d%% (%d) | Never: %d%% (%d) | Quorum: %d%%",
                freqPct, issue.getVotesFrequently(),
                somePct, issue.getVotesSometimes(),
                neverPct, issue.getVotesNever(),
                quorumPct
        ));

        String s = issue.getStatus().toUpperCase();
        statusBadge.setText(" " + s + " ");

        // Update Stepper Pipeline based on status
        boolean s1 = true;
        boolean s2 = s.contains("VERIFICATION") || s.contains("VERIFIED") || s.contains("INVESTIGATION") || s.contains("RESOLVED");
        boolean s3 = s.contains("CLASS VERIFIED") || s.contains("INVESTIGATION") || s.contains("RESOLVED");
        boolean s4 = s.contains("RESOLVED");

        updateStepStyle(step1Label, s1);
        updateStepStyle(step2Label, s2);
        updateStepStyle(step3Label, s3);
        updateStepStyle(step4Label, s4);
    }
}
