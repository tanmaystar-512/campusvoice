package campusvoice.ui;

import campusvoice.model.Student;
import campusvoice.utils.DataStore;
import campusvoice.utils.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Modern Interactive LoginFrame for CampusVoice.
 * Includes 3-way navigation:
 * 1. Student Portal Login
 * 2. New Student Registration
 * 3. Administrator Review Portal
 */
public class LoginFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel formCardsPanel;

    private JButton studentTabBtn;
    private JButton registerTabBtn;
    private JButton adminTabBtn;

    // Student Login fields
    private JTextField studentIdField;
    private JPasswordField studentPasswordField;
    private JCheckBox studentShowPassCheck;

    // Student Registration fields
    private JTextField regNameField;
    private JTextField regIdField;
    private JTextField regRollField;
    private JComboBox<String> regDeptCombo;
    private JComboBox<String> regSectionCombo;
    private JPasswordField regPasswordField;
    private JPasswordField regConfirmPasswordField;

    // Admin fields
    private JTextField adminIdField;
    private JPasswordField adminPasswordField;
    private JCheckBox adminShowPassCheck;

    public LoginFrame() {
        setTitle("CampusVoice - System Authentication & Registration Portal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(540, 720);
        setMinimumSize(new Dimension(500, 640));
        setLocationRelativeTo(null);
        setResizable(true);

        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UIUtils.COLOR_BG);

        // Header Panel with Gradient
        JPanel headerPanel = UIUtils.createHeader(
                "CampusVoice Portal",
                "Anonymous Student Issue Reporting & Class-Level Verification System"
        );
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Center Content Card
        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(UIUtils.COLOR_BG);
        centerWrapper.setBorder(new EmptyBorder(16, 20, 16, 20));

        JPanel mainCard = UIUtils.createCardPanel();
        mainCard.setLayout(new BoxLayout(mainCard, BoxLayout.Y_AXIS));
        mainCard.setPreferredSize(new Dimension(480, 560));

        // Segmented Switcher for 3 Modes: Student Login | Register | Admin
        JPanel roleSwitcher = new JPanel(new GridLayout(1, 3, 6, 0));
        roleSwitcher.setOpaque(false);
        roleSwitcher.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        roleSwitcher.setAlignmentX(Component.LEFT_ALIGNMENT);

        studentTabBtn = new JButton("Student Login");
        studentTabBtn.setFont(UIUtils.FONT_BOLD);
        studentTabBtn.setFocusPainted(false);
        studentTabBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        registerTabBtn = new JButton("Register");
        registerTabBtn.setFont(UIUtils.FONT_BOLD);
        registerTabBtn.setFocusPainted(false);
        registerTabBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        adminTabBtn = new JButton("Admin");
        adminTabBtn.setFont(UIUtils.FONT_BOLD);
        adminTabBtn.setFocusPainted(false);
        adminTabBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        roleSwitcher.add(studentTabBtn);
        roleSwitcher.add(registerTabBtn);
        roleSwitcher.add(adminTabBtn);

        studentTabBtn.addActionListener(e -> switchRole("STUDENT"));
        registerTabBtn.addActionListener(e -> switchRole("REGISTER"));
        adminTabBtn.addActionListener(e -> switchRole("ADMIN"));

        // Form Cards Container (CardLayout)
        cardLayout = new CardLayout();
        formCardsPanel = new JPanel(cardLayout);
        formCardsPanel.setOpaque(false);
        formCardsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel studentCard = createStudentFormCard();
        JPanel registerCard = createRegisterFormCard();
        JPanel adminCard = createAdminFormCard();

        formCardsPanel.add(studentCard, "STUDENT");
        formCardsPanel.add(registerCard, "REGISTER");
        formCardsPanel.add(adminCard, "ADMIN");

        mainCard.add(roleSwitcher);
        mainCard.add(Box.createVerticalStrut(14));
        mainCard.add(formCardsPanel);

        centerWrapper.add(mainCard);

        JScrollPane centerScroll = new JScrollPane(centerWrapper);
        centerScroll.setBorder(null);
        centerScroll.getVerticalScrollBar().setUnitIncrement(14);
        mainPanel.add(centerScroll, BorderLayout.CENTER);

        // Privacy Footer
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(UIUtils.COLOR_BG);
        footerPanel.setBorder(new EmptyBorder(0, 20, 14, 20));

        JLabel privacyNote = new JLabel(
                "<html><center><font color='#64748B'><b>Identity-Protected Reporting:</b> Individual identity is strictly isolated and never attached to submitted complaints.</font></center></html>",
                SwingConstants.CENTER
        );
        privacyNote.setFont(UIUtils.FONT_SMALL);
        footerPanel.add(privacyNote, BorderLayout.CENTER);

        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // Default to Student role
        switchRole("STUDENT");
    }

    private JPanel createStudentFormCard() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        JLabel title = new JLabel("Student Login");
        title.setFont(UIUtils.FONT_SUBTITLE);
        title.setForeground(UIUtils.COLOR_TEXT_MAIN);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel desc = new JLabel("Report campus issues & participate in class verification.");
        desc.setFont(UIUtils.FONT_SMALL);
        desc.setForeground(UIUtils.COLOR_TEXT_MUTED);
        desc.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Interactive 1-Click Autofill Badge
        JPanel hintCard = new JPanel(new BorderLayout(5, 5));
        hintCard.setBackground(new Color(239, 246, 255));
        hintCard.setBorder(new CompoundBorder(
                new LineBorder(new Color(191, 219, 254), 1, true),
                new EmptyBorder(8, 12, 8, 12)
        ));
        hintCard.setCursor(new Cursor(Cursor.HAND_CURSOR));
        hintCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel hintText = new JLabel("<html><b>Quick Demo:</b> Click here to auto-fill (ID: <code>183</code> | Pass: <code>1234</code>)</html>");
        hintText.setFont(UIUtils.FONT_SMALL);
        hintText.setForeground(new Color(30, 64, 175));
        hintCard.add(hintText, BorderLayout.CENTER);

        hintCard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                studentIdField.setText("183");
                studentPasswordField.setText("1234");
                studentIdField.requestFocus();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                hintCard.setBackground(new Color(219, 234, 254));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hintCard.setBackground(new Color(239, 246, 255));
            }
        });

        // Student ID Field
        JLabel idLabel = new JLabel("Student ID / Code");
        idLabel.setFont(UIUtils.FONT_BOLD);
        idLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        idLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        studentIdField = UIUtils.createTextField();
        studentIdField.setAlignmentX(Component.LEFT_ALIGNMENT);
        studentIdField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        // Password Field
        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(UIUtils.FONT_BOLD);
        passLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        studentPasswordField = UIUtils.createPasswordField();
        studentPasswordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        studentPasswordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        studentShowPassCheck = new JCheckBox("Show Password");
        studentShowPassCheck.setFont(UIUtils.FONT_SMALL);
        studentShowPassCheck.setForeground(UIUtils.COLOR_TEXT_MUTED);
        studentShowPassCheck.setOpaque(false);
        studentShowPassCheck.setAlignmentX(Component.LEFT_ALIGNMENT);
        studentShowPassCheck.addActionListener(e -> {
            studentPasswordField.setEchoChar(studentShowPassCheck.isSelected() ? (char) 0 : '•');
        });

        KeyAdapter enterSubmit = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performStudentLogin();
                }
            }
        };
        studentIdField.addKeyListener(enterSubmit);
        studentPasswordField.addKeyListener(enterSubmit);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttonPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        JButton loginButton = UIUtils.createPrimaryButton("Login as Student");
        JButton clearButton = UIUtils.createSecondaryButton("Clear");

        loginButton.addActionListener(e -> performStudentLogin());
        clearButton.addActionListener(e -> clearStudentFields());

        buttonPanel.add(loginButton);
        buttonPanel.add(clearButton);

        // Toggle to Register Link
        JPanel toggleRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        toggleRow.setOpaque(false);
        toggleRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        toggleRow.setBorder(new EmptyBorder(10, 0, 0, 0));

        JLabel newStudentLabel = new JLabel("New student?");
        newStudentLabel.setFont(UIUtils.FONT_SMALL);
        newStudentLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        JButton goToRegisterBtn = new JButton("Create an account here");
        goToRegisterBtn.setFont(UIUtils.FONT_BOLD);
        goToRegisterBtn.setForeground(UIUtils.COLOR_PRIMARY);
        goToRegisterBtn.setBorder(null);
        goToRegisterBtn.setContentAreaFilled(false);
        goToRegisterBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        goToRegisterBtn.addActionListener(e -> switchRole("REGISTER"));

        toggleRow.add(newStudentLabel);
        toggleRow.add(goToRegisterBtn);

        panel.add(title);
        panel.add(Box.createVerticalStrut(3));
        panel.add(desc);
        panel.add(Box.createVerticalStrut(10));
        panel.add(hintCard);
        panel.add(Box.createVerticalStrut(12));
        panel.add(idLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(studentIdField);
        panel.add(Box.createVerticalStrut(10));
        panel.add(passLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(studentPasswordField);
        panel.add(Box.createVerticalStrut(4));
        panel.add(studentShowPassCheck);
        panel.add(Box.createVerticalStrut(14));
        panel.add(buttonPanel);
        panel.add(toggleRow);

        return panel;
    }

    private JPanel createRegisterFormCard() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        JLabel title = new JLabel("New Student Registration");
        title.setFont(UIUtils.FONT_SUBTITLE);
        title.setForeground(UIUtils.COLOR_TEXT_MAIN);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel desc = new JLabel("Create your account to participate in anonymous issue reporting.");
        desc.setFont(UIUtils.FONT_SMALL);
        desc.setForeground(UIUtils.COLOR_TEXT_MUTED);
        desc.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Full Name
        JLabel nameLabel = new JLabel("Full Student Name *");
        nameLabel.setFont(UIUtils.FONT_BOLD);
        nameLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        regNameField = UIUtils.createTextField();
        regNameField.setAlignmentX(Component.LEFT_ALIGNMENT);
        regNameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        // Two-Column: Student ID & Roll Number
        JPanel row1 = new JPanel(new GridLayout(1, 2, 10, 0));
        row1.setOpaque(false);
        row1.setAlignmentX(Component.LEFT_ALIGNMENT);
        row1.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JPanel colId = new JPanel();
        colId.setLayout(new BoxLayout(colId, BoxLayout.Y_AXIS));
        colId.setOpaque(false);
        JLabel idLbl = new JLabel("Student ID / Code *");
        idLbl.setFont(UIUtils.FONT_BOLD);
        regIdField = UIUtils.createTextField();
        colId.add(idLbl);
        colId.add(Box.createVerticalStrut(4));
        colId.add(regIdField);

        JPanel colRoll = new JPanel();
        colRoll.setLayout(new BoxLayout(colRoll, BoxLayout.Y_AXIS));
        colRoll.setOpaque(false);
        JLabel rollLbl = new JLabel("Roll Number *");
        rollLbl.setFont(UIUtils.FONT_BOLD);
        regRollField = UIUtils.createTextField();
        colRoll.add(rollLbl);
        colRoll.add(Box.createVerticalStrut(4));
        colRoll.add(regRollField);

        row1.add(colId);
        row1.add(colRoll);

        // Two-Column: Department & Section
        JPanel row2 = new JPanel(new GridLayout(1, 2, 10, 0));
        row2.setOpaque(false);
        row2.setAlignmentX(Component.LEFT_ALIGNMENT);
        row2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JPanel colDept = new JPanel();
        colDept.setLayout(new BoxLayout(colDept, BoxLayout.Y_AXIS));
        colDept.setOpaque(false);
        JLabel deptLbl = new JLabel("Department / Course *");
        deptLbl.setFont(UIUtils.FONT_BOLD);
        String[] depts = {
                "B.Tech Artificial Intelligence & Data Science",
                "B.Tech Computer Science & Engineering",
                "B.Tech Information Technology",
                "B.Tech Electronics & Communication",
                "B.Tech Mechanical Engineering",
                "B.Tech Civil Engineering"
        };
        regDeptCombo = new JComboBox<>(depts);
        regDeptCombo.setFont(UIUtils.FONT_REGULAR);
        regDeptCombo.setBackground(Color.WHITE);
        colDept.add(deptLbl);
        colDept.add(Box.createVerticalStrut(4));
        colDept.add(regDeptCombo);

        JPanel colSec = new JPanel();
        colSec.setLayout(new BoxLayout(colSec, BoxLayout.Y_AXIS));
        colSec.setOpaque(false);
        JLabel secLbl = new JLabel("Section *");
        secLbl.setFont(UIUtils.FONT_BOLD);
        String[] sections = {"C", "A", "B"};
        regSectionCombo = new JComboBox<>(sections);
        regSectionCombo.setFont(UIUtils.FONT_REGULAR);
        regSectionCombo.setBackground(Color.WHITE);
        colSec.add(secLbl);
        colSec.add(Box.createVerticalStrut(4));
        colSec.add(regSectionCombo);

        row2.add(colDept);
        row2.add(colSec);

        // Two-Column: Password & Confirm Password
        JPanel row3 = new JPanel(new GridLayout(1, 2, 10, 0));
        row3.setOpaque(false);
        row3.setAlignmentX(Component.LEFT_ALIGNMENT);
        row3.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JPanel colPass = new JPanel();
        colPass.setLayout(new BoxLayout(colPass, BoxLayout.Y_AXIS));
        colPass.setOpaque(false);
        JLabel pLbl = new JLabel("Password *");
        pLbl.setFont(UIUtils.FONT_BOLD);
        regPasswordField = UIUtils.createPasswordField();
        colPass.add(pLbl);
        colPass.add(Box.createVerticalStrut(4));
        colPass.add(regPasswordField);

        JPanel colConf = new JPanel();
        colConf.setLayout(new BoxLayout(colConf, BoxLayout.Y_AXIS));
        colConf.setOpaque(false);
        JLabel cLbl = new JLabel("Confirm Password *");
        cLbl.setFont(UIUtils.FONT_BOLD);
        regConfirmPasswordField = UIUtils.createPasswordField();
        colConf.add(cLbl);
        colConf.add(Box.createVerticalStrut(4));
        colConf.add(regConfirmPasswordField);

        row3.add(colPass);
        row3.add(colConf);

        // Submit Button
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttonPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        JButton registerButton = UIUtils.createPrimaryButton("Register Account");
        JButton clearRegButton = UIUtils.createSecondaryButton("Clear");

        registerButton.addActionListener(e -> performRegistration());
        clearRegButton.addActionListener(e -> clearRegistrationFields());

        buttonPanel.add(registerButton);
        buttonPanel.add(clearRegButton);

        // Toggle to Login Link
        JPanel toggleRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        toggleRow.setOpaque(false);
        toggleRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        toggleRow.setBorder(new EmptyBorder(8, 0, 0, 0));

        JLabel hasAccLabel = new JLabel("Already registered?");
        hasAccLabel.setFont(UIUtils.FONT_SMALL);
        hasAccLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        JButton goToLoginBtn = new JButton("Login to Student Portal");
        goToLoginBtn.setFont(UIUtils.FONT_BOLD);
        goToLoginBtn.setForeground(UIUtils.COLOR_PRIMARY);
        goToLoginBtn.setBorder(null);
        goToLoginBtn.setContentAreaFilled(false);
        goToLoginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        goToLoginBtn.addActionListener(e -> switchRole("STUDENT"));

        toggleRow.add(hasAccLabel);
        toggleRow.add(goToLoginBtn);

        panel.add(title);
        panel.add(Box.createVerticalStrut(2));
        panel.add(desc);
        panel.add(Box.createVerticalStrut(10));
        panel.add(nameLabel);
        panel.add(Box.createVerticalStrut(4));
        panel.add(regNameField);
        panel.add(Box.createVerticalStrut(8));
        panel.add(row1);
        panel.add(Box.createVerticalStrut(8));
        panel.add(row2);
        panel.add(Box.createVerticalStrut(8));
        panel.add(row3);
        panel.add(Box.createVerticalStrut(14));
        panel.add(buttonPanel);
        panel.add(toggleRow);

        return panel;
    }

    private JPanel createAdminFormCard() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        JLabel title = new JLabel("Administrator Login");
        title.setFont(UIUtils.FONT_SUBTITLE);
        title.setForeground(UIUtils.COLOR_TEXT_MAIN);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel desc = new JLabel("Inspect class-verified reports, assign departments, and resolve issues.");
        desc.setFont(UIUtils.FONT_SMALL);
        desc.setForeground(UIUtils.COLOR_TEXT_MUTED);
        desc.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Interactive 1-Click Autofill Badge for Admin
        JPanel hintCard = new JPanel(new BorderLayout(5, 5));
        hintCard.setBackground(new Color(254, 243, 199));
        hintCard.setBorder(new CompoundBorder(
                new LineBorder(new Color(253, 230, 138), 1, true),
                new EmptyBorder(8, 12, 8, 12)
        ));
        hintCard.setCursor(new Cursor(Cursor.HAND_CURSOR));
        hintCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel hintText = new JLabel("<html><b>Quick Demo:</b> Click here to auto-fill (User: <code>admin</code> | Pass: <code>admin123</code>)</html>");
        hintText.setFont(UIUtils.FONT_SMALL);
        hintText.setForeground(new Color(146, 64, 14));
        hintCard.add(hintText, BorderLayout.CENTER);

        hintCard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                adminIdField.setText("admin");
                adminPasswordField.setText("admin123");
                adminIdField.requestFocus();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                hintCard.setBackground(new Color(253, 230, 138));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hintCard.setBackground(new Color(254, 243, 199));
            }
        });

        // Admin Username Field
        JLabel idLabel = new JLabel("Administrator Username / ID");
        idLabel.setFont(UIUtils.FONT_BOLD);
        idLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        idLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        adminIdField = UIUtils.createTextField();
        adminIdField.setAlignmentX(Component.LEFT_ALIGNMENT);
        adminIdField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        // Admin Password Field
        JLabel passLabel = new JLabel("Admin Password");
        passLabel.setFont(UIUtils.FONT_BOLD);
        passLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        adminPasswordField = UIUtils.createPasswordField();
        adminPasswordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        adminPasswordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        adminShowPassCheck = new JCheckBox("Show Password");
        adminShowPassCheck.setFont(UIUtils.FONT_SMALL);
        adminShowPassCheck.setForeground(UIUtils.COLOR_TEXT_MUTED);
        adminShowPassCheck.setOpaque(false);
        adminShowPassCheck.setAlignmentX(Component.LEFT_ALIGNMENT);
        adminShowPassCheck.addActionListener(e -> {
            adminPasswordField.setEchoChar(adminShowPassCheck.isSelected() ? (char) 0 : '•');
        });

        KeyAdapter enterSubmit = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performAdminLogin();
                }
            }
        };
        adminIdField.addKeyListener(enterSubmit);
        adminPasswordField.addKeyListener(enterSubmit);

        // Buttons Panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttonPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        JButton loginButton = UIUtils.createPrimaryButton("Login as Admin");
        JButton clearButton = UIUtils.createSecondaryButton("Clear");

        loginButton.addActionListener(e -> performAdminLogin());
        clearButton.addActionListener(e -> clearAdminFields());

        buttonPanel.add(loginButton);
        buttonPanel.add(clearButton);

        panel.add(title);
        panel.add(Box.createVerticalStrut(3));
        panel.add(desc);
        panel.add(Box.createVerticalStrut(10));
        panel.add(hintCard);
        panel.add(Box.createVerticalStrut(14));
        panel.add(idLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(adminIdField);
        panel.add(Box.createVerticalStrut(12));
        panel.add(passLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(adminPasswordField);
        panel.add(Box.createVerticalStrut(4));
        panel.add(adminShowPassCheck);
        panel.add(Box.createVerticalStrut(16));
        panel.add(buttonPanel);

        return panel;
    }

    private void switchRole(String role) {
        cardLayout.show(formCardsPanel, role);

        resetTabButtonStyle(studentTabBtn, "STUDENT".equals(role));
        resetTabButtonStyle(registerTabBtn, "REGISTER".equals(role));
        resetTabButtonStyle(adminTabBtn, "ADMIN".equals(role));

        if ("STUDENT".equals(role)) {
            studentIdField.requestFocus();
        } else if ("REGISTER".equals(role)) {
            regNameField.requestFocus();
        } else {
            adminIdField.requestFocus();
        }
    }

    private void resetTabButtonStyle(JButton btn, boolean isActive) {
        if (isActive) {
            btn.setBackground(UIUtils.COLOR_PRIMARY);
            btn.setForeground(Color.WHITE);
            btn.setBorder(new EmptyBorder(8, 10, 8, 10));
        } else {
            btn.setBackground(new Color(241, 245, 249));
            btn.setForeground(UIUtils.COLOR_TEXT_MUTED);
            btn.setBorder(new CompoundBorder(
                    new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                    new EmptyBorder(7, 9, 7, 9)
            ));
        }
    }

    private void performStudentLogin() {
        String studentId = studentIdField.getText().trim();
        String password = new String(studentPasswordField.getPassword()).trim();

        if (studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your Student ID.", "Input Required", JOptionPane.WARNING_MESSAGE);
            studentIdField.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your Password.", "Input Required", JOptionPane.WARNING_MESSAGE);
            studentPasswordField.requestFocus();
            return;
        }

        Student student = DataStore.getInstance().authenticateStudent(studentId, password);
        if (student != null) {
            StudentDashboard dashboard = new StudentDashboard();
            dashboard.setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid Student ID or Password.\n\nTip: Use Student ID: 183 & Pass: 1234, or click 'Register' above to create a new account.",
                    "Student Authentication Failed",
                    JOptionPane.ERROR_MESSAGE
            );
            studentPasswordField.setText("");
            studentPasswordField.requestFocus();
        }
    }

    private void performRegistration() {
        String name = regNameField.getText().trim();
        String id = regIdField.getText().trim();
        String roll = regRollField.getText().trim();
        String dept = (String) regDeptCombo.getSelectedItem();
        String sec = (String) regSectionCombo.getSelectedItem();
        String pass = new String(regPasswordField.getPassword()).trim();
        String conf = new String(regConfirmPasswordField.getPassword()).trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Full Name.", "Validation", JOptionPane.WARNING_MESSAGE);
            regNameField.requestFocus();
            return;
        }

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Student ID / Code.", "Validation", JOptionPane.WARNING_MESSAGE);
            regIdField.requestFocus();
            return;
        }

        if (roll.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Roll Number.", "Validation", JOptionPane.WARNING_MESSAGE);
            regRollField.requestFocus();
            return;
        }

        if (pass.isEmpty() || pass.length() < 4) {
            JOptionPane.showMessageDialog(this, "Password must be at least 4 characters.", "Validation", JOptionPane.WARNING_MESSAGE);
            regPasswordField.requestFocus();
            return;
        }

        if (!pass.equals(conf)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match. Please re-enter.", "Validation", JOptionPane.ERROR_MESSAGE);
            regConfirmPasswordField.setText("");
            regConfirmPasswordField.requestFocus();
            return;
        }

        DataStore store = DataStore.getInstance();
        if (store.isStudentIdRegistered(id)) {
            JOptionPane.showMessageDialog(this, "Student ID '" + id + "' is already registered. Please login.", "Already Exists", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean success = store.registerStudent(id, pass, name, roll, dept, sec);
        if (success) {
            JOptionPane.showMessageDialog(
                    this,
                    "Registration Successful!\n\nWelcome " + name + "!\nYour account has been created.\n\nYou can now log in using:\nStudent ID: " + id,
                    "Account Created",
                    JOptionPane.INFORMATION_MESSAGE
            );

            clearRegistrationFields();
            switchRole("STUDENT");
            studentIdField.setText(id);
            studentPasswordField.requestFocus();
        }
    }

    private void performAdminLogin() {
        String adminId = adminIdField.getText().trim();
        String password = new String(adminPasswordField.getPassword()).trim();

        if (adminId.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill Admin Username and Password.", "Input Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if ("admin".equalsIgnoreCase(adminId) && "admin123".equals(password)) {
            AdminDashboard adminDashboard = new AdminDashboard();
            adminDashboard.setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid Administrator credentials.\n\nTip: Use Username: admin & Password: admin123",
                    "Admin Authentication Failed",
                    JOptionPane.ERROR_MESSAGE
            );
            adminPasswordField.setText("");
            adminPasswordField.requestFocus();
        }
    }

    private void clearStudentFields() {
        studentIdField.setText("");
        studentPasswordField.setText("");
        studentIdField.requestFocus();
    }

    private void clearRegistrationFields() {
        regNameField.setText("");
        regIdField.setText("");
        regRollField.setText("");
        regPasswordField.setText("");
        regConfirmPasswordField.setText("");
    }

    private void clearAdminFields() {
        adminIdField.setText("");
        adminPasswordField.setText("");
        adminIdField.requestFocus();
    }
}
