package campusvoice.ui;

import campusvoice.model.Issue;
import campusvoice.utils.DataStore;
import campusvoice.utils.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Modern Interactive VerificationFrame for CampusVoice.
 * Includes interactive selectable voting cards, custom live progress meters for votes,
 * class participation quorum meter (30% threshold), and real-time status transitions.
 */
public class VerificationFrame extends JFrame {

    private final StudentDashboard parentDashboard;

    private JTextField tokenField;
    private JComboBox<String> issueSelector;

    // Interactive Voting Selection
    private String selectedVoteOption = null;
    private JPanel frequentlyCard;
    private JPanel sometimesCard;
    private JPanel neverCard;

    // Graphical Result Progress Bars & Metrics
    private JProgressBar frequentlyBar;
    private JProgressBar sometimesBar;
    private JProgressBar neverBar;
    private JProgressBar participationBar;

    private JLabel frequentlyPctText;
    private JLabel sometimesPctText;
    private JLabel neverPctText;
    private JLabel participationText;
    private JLabel verificationStatusBadge;
    private JLabel quorumStatusLabel;

    public VerificationFrame(StudentDashboard parentDashboard) {
        this.parentDashboard = parentDashboard;

        setTitle("CampusVoice - Class-Level Verification Voting");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(780, 800);
        setMinimumSize(new Dimension(680, 620));
        setLocationRelativeTo(parentDashboard != null ? parentDashboard : null);

        initComponents();
    }

    private void initComponents() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UIUtils.COLOR_BG);

        // Header Panel with Gradient
        JPanel headerPanel = UIUtils.createHeader(
                "Class-Level Issue Verification",
                "Token-Based Anonymous Voting: Validate collective classmate feedback with 30% cohort quorum."
        );
        rootPanel.add(headerPanel, BorderLayout.NORTH);

        // Scrollable content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.COLOR_BG);
        contentPanel.setBorder(new EmptyBorder(16, 24, 16, 24));

        // Card 1: Token & Issue Selection
        JPanel authCard = UIUtils.createCardPanel();
        authCard.setLayout(new BoxLayout(authCard, BoxLayout.Y_AXIS));

        JLabel authTitle = new JLabel("1. Verification Authorization & Issue Selection");
        authTitle.setFont(UIUtils.FONT_SUBTITLE);
        authTitle.setForeground(UIUtils.COLOR_TEXT_MAIN);
        authTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel tokenLabel = new JLabel("Daily Verification Token *");
        tokenLabel.setFont(UIUtils.FONT_BOLD);
        tokenLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        tokenLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel tokenInputRow = new JPanel(new BorderLayout(8, 0));
        tokenInputRow.setOpaque(false);
        tokenInputRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        tokenInputRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        tokenField = UIUtils.createTextField();
        tokenField.setText(DataStore.DEMO_TOKEN);

        JButton pasteTokenBtn = UIUtils.createSecondaryButton("Insert Active Token");
        pasteTokenBtn.addActionListener(e -> tokenField.setText(DataStore.DEMO_TOKEN));

        tokenInputRow.add(tokenField, BorderLayout.CENTER);
        tokenInputRow.add(pasteTokenBtn, BorderLayout.EAST);

        JLabel issueLabel = new JLabel("Select Issue from Cohort *");
        issueLabel.setFont(UIUtils.FONT_BOLD);
        issueLabel.setForeground(UIUtils.COLOR_TEXT_MAIN);
        issueLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        issueSelector = new JComboBox<>();
        issueSelector.setFont(UIUtils.FONT_REGULAR);
        issueSelector.setBackground(Color.WHITE);
        issueSelector.setAlignmentX(Component.LEFT_ALIGNMENT);
        issueSelector.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        populateIssueSelector();

        authCard.add(authTitle);
        authCard.add(Box.createVerticalStrut(12));
        authCard.add(tokenLabel);
        authCard.add(Box.createVerticalStrut(5));
        authCard.add(tokenInputRow);
        authCard.add(Box.createVerticalStrut(14));
        authCard.add(issueLabel);
        authCard.add(Box.createVerticalStrut(5));
        authCard.add(issueSelector);

        contentPanel.add(authCard);
        contentPanel.add(Box.createVerticalStrut(16));

        // Card 2: Interactive Selectable Voting Cards
        JPanel voteCard = UIUtils.createCardPanel();
        voteCard.setLayout(new BoxLayout(voteCard, BoxLayout.Y_AXIS));

        JLabel voteTitle = new JLabel("2. Cast Your Confidential Vote");
        voteTitle.setFont(UIUtils.FONT_SUBTITLE);
        voteTitle.setForeground(UIUtils.COLOR_TEXT_MAIN);
        voteTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel questionLabel = new JLabel("\"Have you also experienced this issue in campus / class?\"");
        questionLabel.setFont(UIUtils.FONT_BOLD);
        questionLabel.setForeground(UIUtils.COLOR_PRIMARY);
        questionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel optionCardsGrid = new JPanel(new GridLayout(1, 3, 12, 0));
        optionCardsGrid.setOpaque(false);
        optionCardsGrid.setAlignmentX(Component.LEFT_ALIGNMENT);
        optionCardsGrid.setMaximumSize(new Dimension(Integer.MAX_VALUE, 85));

        frequentlyCard = createVoteOptionCard("Frequently", "Experienced on a regular basis", UIUtils.COLOR_PRIMARY);
        sometimesCard = createVoteOptionCard("Sometimes", "Experienced occasionally", UIUtils.COLOR_WARNING);
        neverCard = createVoteOptionCard("Never", "Have not faced this issue", UIUtils.COLOR_TEXT_MUTED);

        optionCardsGrid.add(frequentlyCard);
        optionCardsGrid.add(sometimesCard);
        optionCardsGrid.add(neverCard);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        JButton submitVoteBtn = UIUtils.createPrimaryButton("Submit Confidential Vote");
        submitVoteBtn.addActionListener(e -> processVoteSubmission());
        btnRow.add(submitVoteBtn);

        voteCard.add(voteTitle);
        voteCard.add(Box.createVerticalStrut(6));
        voteCard.add(questionLabel);
        voteCard.add(Box.createVerticalStrut(12));
        voteCard.add(optionCardsGrid);
        voteCard.add(Box.createVerticalStrut(14));
        voteCard.add(btnRow);

        contentPanel.add(voteCard);
        contentPanel.add(Box.createVerticalStrut(16));

        // Card 3: Graphical Live Verification Results
        JPanel resultCard = createGraphicalResultCard();
        contentPanel.add(resultCard);

        issueSelector.addActionListener(e -> updateResultsDisplay());
        updateResultsDisplay();

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        rootPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(rootPanel);
    }

    private JPanel createVoteOptionCard(String title, String subtitle, Color color) {
        JPanel card = new JPanel(new BorderLayout(5, 4));
        card.setBackground(new Color(248, 250, 252));
        card.setBorder(new CompoundBorder(
                new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                new EmptyBorder(10, 12, 10, 12)
        ));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(UIUtils.FONT_BOLD);
        titleLbl.setForeground(color);

        JLabel subLbl = new JLabel("<html>" + subtitle + "</html>");
        subLbl.setFont(UIUtils.FONT_SMALL);
        subLbl.setForeground(UIUtils.COLOR_TEXT_MUTED);

        card.add(titleLbl, BorderLayout.NORTH);
        card.add(subLbl, BorderLayout.CENTER);

        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectVoteOption(title);
            }
        });
        return card;
    }

    private void selectVoteOption(String option) {
        this.selectedVoteOption = option;

        resetCardStyle(frequentlyCard, "Frequently".equals(option), UIUtils.COLOR_PRIMARY);
        resetCardStyle(sometimesCard, "Sometimes".equals(option), UIUtils.COLOR_WARNING);
        resetCardStyle(neverCard, "Never".equals(option), UIUtils.COLOR_TEXT_MUTED);
    }

    private void resetCardStyle(JPanel card, boolean isSelected, Color activeColor) {
        if (isSelected) {
            card.setBackground(new Color(239, 246, 255));
            card.setBorder(new CompoundBorder(
                    new LineBorder(activeColor, 2, true),
                    new EmptyBorder(9, 11, 9, 11)
            ));
        } else {
            card.setBackground(new Color(248, 250, 252));
            card.setBorder(new CompoundBorder(
                    new LineBorder(UIUtils.COLOR_BORDER, 1, true),
                    new EmptyBorder(10, 12, 10, 12)
            ));
        }
    }

    private JPanel createGraphicalResultCard() {
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("3. Aggregated Class Verification Metrics");
        title.setFont(UIUtils.FONT_SUBTITLE);
        title.setForeground(UIUtils.COLOR_TEXT_MAIN);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel privacyNotice = new JLabel("<html><font color='#64748B'><i>Identity Protected: Individual student votes and names are never recorded. Only collective tallies are visible.</i></font></html>");
        privacyNotice.setFont(UIUtils.FONT_SMALL);
        privacyNotice.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel progressGrid = new JPanel(new GridLayout(4, 1, 0, 10));
        progressGrid.setOpaque(false);
        progressGrid.setAlignmentX(Component.LEFT_ALIGNMENT);
        progressGrid.setBorder(new EmptyBorder(14, 0, 14, 0));

        frequentlyBar = UIUtils.createProgressBar(0, UIUtils.COLOR_PRIMARY);
        frequentlyPctText = new JLabel("Frequently: 0% (0 votes)");
        frequentlyPctText.setFont(UIUtils.FONT_BOLD);

        sometimesBar = UIUtils.createProgressBar(0, UIUtils.COLOR_WARNING);
        sometimesPctText = new JLabel("Sometimes: 0% (0 votes)");
        sometimesPctText.setFont(UIUtils.FONT_BOLD);

        neverBar = UIUtils.createProgressBar(0, UIUtils.COLOR_TEXT_MUTED);
        neverPctText = new JLabel("Never: 0% (0 votes)");
        neverPctText.setFont(UIUtils.FONT_BOLD);

        participationBar = UIUtils.createProgressBar(0, UIUtils.COLOR_SUCCESS);
        participationText = new JLabel("Class Participation: 0% (Quorum: 30%)");
        participationText.setFont(UIUtils.FONT_BOLD);

        progressGrid.add(createProgressRow(frequentlyPctText, frequentlyBar));
        progressGrid.add(createProgressRow(sometimesPctText, sometimesBar));
        progressGrid.add(createProgressRow(neverPctText, neverBar));
        progressGrid.add(createProgressRow(participationText, participationBar));

        // Outcome Row
        JPanel outcomeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        outcomeRow.setOpaque(false);
        outcomeRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel outcomeTitle = new JLabel("Verification Outcome:");
        outcomeTitle.setFont(UIUtils.FONT_BOLD);

        verificationStatusBadge = UIUtils.createStatusBadge("UNDER VERIFICATION");
        quorumStatusLabel = new JLabel("(Pending minimum 30% class quorum)");
        quorumStatusLabel.setFont(UIUtils.FONT_SMALL);
        quorumStatusLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        outcomeRow.add(outcomeTitle);
        outcomeRow.add(verificationStatusBadge);
        outcomeRow.add(quorumStatusLabel);

        card.add(title);
        card.add(Box.createVerticalStrut(3));
        card.add(privacyNotice);
        card.add(Box.createVerticalStrut(10));
        card.add(progressGrid);
        card.add(Box.createVerticalStrut(6));
        card.add(outcomeRow);

        return card;
    }

    private JPanel createProgressRow(JLabel label, JProgressBar bar) {
        JPanel row = new JPanel(new BorderLayout(16, 0));
        row.setOpaque(false);
        label.setPreferredSize(new Dimension(300, 24));
        row.add(label, BorderLayout.WEST);
        row.add(bar, BorderLayout.CENTER);
        return row;
    }

    private void populateIssueSelector() {
        issueSelector.removeAllItems();
        List<Issue> issues = DataStore.getInstance().getAllIssues();
        for (Issue issue : issues) {
            issueSelector.addItem(issue.getIssueId() + " - [" + issue.getCategory() + "] " + issue.getTitle());
        }
    }

    private void processVoteSubmission() {
        String enteredToken = tokenField.getText().trim();
        DataStore store = DataStore.getInstance();

        // 1. Token Validation Check
        String tokenStatus = store.validateToken(enteredToken);

        if ("INVALID".equals(tokenStatus)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid or expired token.\n\nPlease enter an active daily token (e.g. CV1832026).",
                    "Token Validation Error",
                    JOptionPane.ERROR_MESSAGE
            );
            tokenField.requestFocus();
            return;
        }

        if ("USED".equals(tokenStatus)) {
            JOptionPane.showMessageDialog(
                    this,
                    "This token has already been used.\n\nEach token authorizes exactly one voting session to guarantee democratic fairness.",
                    "Duplicate Vote Prevented",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // 2. Voting Selection Check
        if (selectedVoteOption == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select one of the voting options (Frequently, Sometimes, or Never).",
                    "Selection Required",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // 3. Find Selected Issue
        String selectedItem = (String) issueSelector.getSelectedItem();
        if (selectedItem == null) return;
        String issueId = selectedItem.split(" ")[0].trim();
        Issue issue = store.findIssueById(issueId);

        if (issue == null) {
            JOptionPane.showMessageDialog(this, "Issue not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 4. Record Vote & Consume Token
        issue.recordVote(selectedVoteOption);
        store.consumeDemoToken();

        if (parentDashboard != null) {
            parentDashboard.refreshDashboardData();
        }

        updateResultsDisplay();

        String statusNotice = issue.isClassVerified() ? "CLASS VERIFIED (Quorum Achieved)" : "UNDER VERIFICATION";
        JOptionPane.showMessageDialog(
                this,
                "Vote submitted successfully!\n\n" +
                        "Issue ID: " + issue.getIssueId() + "\n" +
                        "Your Vote: " + selectedVoteOption + "\n" +
                        "Verification Outcome: " + statusNotice + "\n\n" +
                        "Token " + enteredToken + " is now consumed.",
                "Vote Confirmed",
                JOptionPane.INFORMATION_MESSAGE
        );

        selectedVoteOption = null;
        resetCardStyle(frequentlyCard, false, UIUtils.COLOR_PRIMARY);
        resetCardStyle(sometimesCard, false, UIUtils.COLOR_WARNING);
        resetCardStyle(neverCard, false, UIUtils.COLOR_TEXT_MUTED);
    }

    private void updateResultsDisplay() {
        String selectedItem = (String) issueSelector.getSelectedItem();
        if (selectedItem == null) return;

        String issueId = selectedItem.split(" ")[0].trim();
        Issue issue = DataStore.getInstance().findIssueById(issueId);
        if (issue == null) return;

        int freqPct = (int) issue.getFrequentlyPercentage();
        int somePct = (int) issue.getSometimesPercentage();
        int neverPct = (int) issue.getNeverPercentage();
        int partPct = (int) issue.getParticipationRate();

        frequentlyBar.setValue(freqPct);
        sometimesBar.setValue(somePct);
        neverBar.setValue(neverPct);
        participationBar.setValue(partPct);

        frequentlyPctText.setText(String.format("Frequently Faced: %d%% (%d votes)", freqPct, issue.getVotesFrequently()));
        sometimesPctText.setText(String.format("Sometimes Faced: %d%% (%d votes)", somePct, issue.getVotesSometimes()));
        neverPctText.setText(String.format("Never Faced: %d%% (%d votes)", neverPct, issue.getVotesNever()));
        participationText.setText(String.format("Class Participation: %d%% (%d / %d students)", partPct, issue.getTotalVotes(), Issue.ESTIMATED_CLASS_SIZE));

        boolean isVerified = issue.isClassVerified();
        if (isVerified) {
            verificationStatusBadge.setText(" CLASS VERIFIED ");
            verificationStatusBadge.setBackground(new Color(209, 250, 229));
            verificationStatusBadge.setForeground(UIUtils.COLOR_SUCCESS);
            quorumStatusLabel.setText("(30% Quorum & 60% Confirmation Met)");
            quorumStatusLabel.setForeground(UIUtils.COLOR_SUCCESS);
        } else {
            verificationStatusBadge.setText(" UNDER VERIFICATION ");
            verificationStatusBadge.setBackground(new Color(254, 243, 199));
            verificationStatusBadge.setForeground(UIUtils.COLOR_WARNING);
            quorumStatusLabel.setText("(Pending required 30% class cohort votes)");
            quorumStatusLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);
        }
    }
}
