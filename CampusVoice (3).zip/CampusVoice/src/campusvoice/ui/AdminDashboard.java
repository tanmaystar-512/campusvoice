package campusvoice.ui;

import campusvoice.model.Issue;
import campusvoice.utils.DataStore;
import campusvoice.utils.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Modern Interactive AdminDashboard for CampusVoice.
 * Includes interactive metric counter cards, dynamic live search filtering,
 * instant row inspection, and 1-click status transitions.
 */
public class AdminDashboard extends JFrame {

    private final StudentDashboard parentDashboard;

    private JLabel totalCountLabel;
    private JLabel reportedCountLabel;
    private JLabel verifiedCountLabel;
    private JLabel resolvedCountLabel;

    private JComboBox<String> categoryFilterCombo;
    private JComboBox<String> statusFilterCombo;
    private JTextField liveSearchField;
    private JTable adminTable;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> rowSorter;

    // Quick Action Bar for Selected Issue
    private JLabel selectedIssueInfoLabel;
    private JButton markInvestigatingBtn;
    private JButton markResolvedBtn;
    private JButton markReopenedBtn;

    public AdminDashboard() {
        this(null);
    }

    public AdminDashboard(StudentDashboard parentDashboard) {
        this.parentDashboard = parentDashboard;

        setTitle("CampusVoice - Administrative Review Dashboard");
        setDefaultCloseOperation(parentDashboard == null ? JFrame.EXIT_ON_CLOSE : JFrame.DISPOSE_ON_CLOSE);
        setSize(1020, 780);
        setMinimumSize(new Dimension(880, 620));
        setLocationRelativeTo(parentDashboard != null ? parentDashboard : null);

        initComponents();
        loadTableData();
    }

    private void initComponents() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UIUtils.COLOR_BG);

        // Header Panel with Gradient & Admin Logout
        JPanel headerPanel = new JPanel(new BorderLayout(15, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(15, 23, 42),
                        getWidth(), getHeight(), new Color(30, 58, 138)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        headerPanel.setBorder(new EmptyBorder(16, 24, 16, 24));

        JPanel titleBlock = new JPanel();
        titleBlock.setLayout(new BoxLayout(titleBlock, BoxLayout.Y_AXIS));
        titleBlock.setOpaque(false);

        JLabel titleLbl = new JLabel("College Administration & Department Review");
        titleLbl.setFont(UIUtils.FONT_TITLE);
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel("Inspect class-verified student issues, assign departmental actions, and record resolutions.");
        subLbl.setFont(UIUtils.FONT_REGULAR);
        subLbl.setForeground(new Color(224, 231, 255));

        titleBlock.add(titleLbl);
        titleBlock.add(Box.createVerticalStrut(3));
        titleBlock.add(subLbl);

        JButton logoutBtn = UIUtils.createDangerButton("Admin Logout");
        logoutBtn.addActionListener(e -> performAdminLogout());

        headerPanel.add(titleBlock, BorderLayout.WEST);
        headerPanel.add(logoutBtn, BorderLayout.EAST);
        rootPanel.add(headerPanel, BorderLayout.NORTH);

        // Scrollable Content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.COLOR_BG);
        contentPanel.setBorder(new EmptyBorder(16, 24, 20, 24));

        // Metric Counters Row (Interactive Filters)
        JPanel metricsRow = createMetricsCards();
        contentPanel.add(metricsRow);
        contentPanel.add(Box.createVerticalStrut(16));

        // Filters & Live Search Toolbar Card
        JPanel filterCard = UIUtils.createCardPanel();
        filterCard.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 6));

        JLabel catLbl = new JLabel("Category:");
        catLbl.setFont(UIUtils.FONT_BOLD);

        categoryFilterCombo = new JComboBox<>(new String[]{
                "All Categories", "Classroom", "Faculty", "Laboratory", "Hostel", "Canteen", "Administration", "Other"
        });
        categoryFilterCombo.setFont(UIUtils.FONT_REGULAR);
        categoryFilterCombo.setBackground(Color.WHITE);
        categoryFilterCombo.addActionListener(e -> loadTableData());

        JLabel statusLbl = new JLabel("Status:");
        statusLbl.setFont(UIUtils.FONT_BOLD);

        statusFilterCombo = new JComboBox<>(new String[]{
                "All Statuses", "REPORTED", "UNDER VERIFICATION", "CLASS VERIFIED", "RESOLVED", "REOPENED"
        });
        statusFilterCombo.setFont(UIUtils.FONT_REGULAR);
        statusFilterCombo.setBackground(Color.WHITE);
        statusFilterCombo.addActionListener(e -> loadTableData());

        JLabel searchLbl = new JLabel("Search:");
        searchLbl.setFont(UIUtils.FONT_BOLD);

        liveSearchField = UIUtils.createTextField();
        liveSearchField.setPreferredSize(new Dimension(170, 32));
        liveSearchField.setToolTipText("Search title, ID or category live");

        liveSearchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { applyLiveSearch(); }
            @Override
            public void removeUpdate(DocumentEvent e) { applyLiveSearch(); }
            @Override
            public void changedUpdate(DocumentEvent e) { applyLiveSearch(); }

            private void applyLiveSearch() {
                String q = liveSearchField.getText().trim();
                if (q.isEmpty()) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + q));
                }
            }
        });

        JButton refreshBtn = UIUtils.createSecondaryButton("Refresh");
        refreshBtn.addActionListener(e -> loadTableData());

        filterCard.add(catLbl);
        filterCard.add(categoryFilterCombo);
        filterCard.add(statusLbl);
        filterCard.add(statusFilterCombo);
        filterCard.add(searchLbl);
        filterCard.add(liveSearchField);
        filterCard.add(refreshBtn);

        contentPanel.add(filterCard);
        contentPanel.add(Box.createVerticalStrut(16));

        // Interactive Selected Issue Action Bar
        JPanel actionBar = createSelectedIssueActionBar();
        contentPanel.add(actionBar);
        contentPanel.add(Box.createVerticalStrut(16));

        // Table Card
        JPanel tableCard = UIUtils.createCardPanel();
        tableCard.setLayout(new BorderLayout(8, 10));

        JLabel tableTitle = new JLabel("College Issues Register (Click any row to execute status action)");
        tableTitle.setFont(UIUtils.FONT_SUBTITLE);
        tableCard.add(tableTitle, BorderLayout.NORTH);

        String[] headers = {"Issue ID", "Category", "Issue Title", "Reported Date", "Class Verification", "Status"};
        tableModel = new DefaultTableModel(headers, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        adminTable = new JTable(tableModel);
        adminTable.setFont(UIUtils.FONT_REGULAR);
        adminTable.setRowHeight(34);
        adminTable.getTableHeader().setFont(UIUtils.FONT_BOLD);
        adminTable.getTableHeader().setBackground(new Color(241, 245, 249));

        rowSorter = new TableRowSorter<>(tableModel);
        adminTable.setRowSorter(rowSorter);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        adminTable.getColumnModel().getColumn(0).setCellRenderer(center);
        adminTable.getColumnModel().getColumn(1).setCellRenderer(center);
        adminTable.getColumnModel().getColumn(3).setCellRenderer(center);
        adminTable.getColumnModel().getColumn(4).setCellRenderer(center);
        adminTable.getColumnModel().getColumn(5).setCellRenderer(center);

        // Selection Listener for Instant Action Bar Updates
        adminTable.getSelectionModel().addListSelectionListener(e -> updateSelectedIssueDisplay());
        adminTable.setFillsViewportHeight(true);

        JScrollPane scroll = new JScrollPane(adminTable);
        scroll.setPreferredSize(new Dimension(940, 260));
        scroll.setBorder(new LineBorder(UIUtils.COLOR_BORDER, 1, true));
        tableCard.add(scroll, BorderLayout.CENTER);

        contentPanel.add(tableCard);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        rootPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(rootPanel);
    }

    private JPanel createMetricsCards() {
        JPanel row = new JPanel(new GridLayout(1, 4, 12, 0));
        row.setOpaque(false);

        totalCountLabel = new JLabel("0", SwingConstants.CENTER);
        reportedCountLabel = new JLabel("0", SwingConstants.CENTER);
        verifiedCountLabel = new JLabel("0", SwingConstants.CENTER);
        resolvedCountLabel = new JLabel("0", SwingConstants.CENTER);

        JPanel c1 = createStatCard("Total Issues", totalCountLabel, UIUtils.COLOR_PRIMARY);
        JPanel c2 = createStatCard("Reported", reportedCountLabel, UIUtils.COLOR_TEXT_MUTED);
        JPanel c3 = createStatCard("Class Verified", verifiedCountLabel, UIUtils.COLOR_WARNING);
        JPanel c4 = createStatCard("Resolved", resolvedCountLabel, UIUtils.COLOR_SUCCESS);

        c1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                statusFilterCombo.setSelectedItem("All Statuses");
            }
        });
        c2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                statusFilterCombo.setSelectedItem("REPORTED");
            }
        });
        c3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                statusFilterCombo.setSelectedItem("CLASS VERIFIED");
            }
        });
        c4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                statusFilterCombo.setSelectedItem("RESOLVED");
            }
        });

        row.add(c1);
        row.add(c2);
        row.add(c3);
        row.add(c4);

        return row;
    }

    private JPanel createStatCard(String title, JLabel valLabel, Color c) {
        JPanel p = UIUtils.createCardPanel();
        p.setLayout(new BorderLayout(4, 4));
        p.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel t = new JLabel(title);
        t.setFont(UIUtils.FONT_SMALL);
        t.setForeground(UIUtils.COLOR_TEXT_MUTED);

        valLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        valLabel.setForeground(c);

        p.add(t, BorderLayout.NORTH);
        p.add(valLabel, BorderLayout.CENTER);
        return p;
    }

    private JPanel createSelectedIssueActionBar() {
        JPanel panel = UIUtils.createCardPanel();
        panel.setLayout(new BorderLayout(10, 10));

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        JLabel heading = new JLabel("1-Click Status Execution");
        heading.setFont(UIUtils.FONT_BOLD);
        heading.setForeground(UIUtils.COLOR_TEXT_MAIN);

        selectedIssueInfoLabel = new JLabel("Select an issue from the table below to apply status actions.");
        selectedIssueInfoLabel.setFont(UIUtils.FONT_SMALL);
        selectedIssueInfoLabel.setForeground(UIUtils.COLOR_TEXT_MUTED);

        left.add(heading);
        left.add(Box.createVerticalStrut(2));
        left.add(selectedIssueInfoLabel);

        JPanel rightBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightBtns.setOpaque(false);

        markInvestigatingBtn = UIUtils.createSecondaryButton("Under Investigation");
        markResolvedBtn = UIUtils.createSuccessButton("Mark Resolved");
        markReopenedBtn = UIUtils.createDangerButton("Reopen Issue");

        markInvestigatingBtn.setEnabled(false);
        markResolvedBtn.setEnabled(false);
        markReopenedBtn.setEnabled(false);

        markInvestigatingBtn.addActionListener(e -> applyStatusToSelected("UNDER INVESTIGATION"));
        markResolvedBtn.addActionListener(e -> applyStatusToSelected("RESOLVED"));
        markReopenedBtn.addActionListener(e -> applyStatusToSelected("REOPENED"));

        rightBtns.add(markInvestigatingBtn);
        rightBtns.add(markResolvedBtn);
        rightBtns.add(markReopenedBtn);

        panel.add(left, BorderLayout.WEST);
        panel.add(rightBtns, BorderLayout.EAST);
        return panel;
    }

    private void updateSelectedIssueDisplay() {
        int selectedRow = adminTable.getSelectedRow();
        if (selectedRow == -1) {
            selectedIssueInfoLabel.setText("Select an issue from the table below to apply status actions.");
            markInvestigatingBtn.setEnabled(false);
            markResolvedBtn.setEnabled(false);
            markReopenedBtn.setEnabled(false);
            return;
        }

        String issueId = (String) adminTable.getValueAt(selectedRow, 0);
        Issue issue = DataStore.getInstance().findIssueById(issueId);

        if (issue != null) {
            selectedIssueInfoLabel.setText(String.format(
                    "Selected: [%s] \"%s\" | Current: %s",
                    issue.getIssueId(), issue.getTitle(), issue.getStatus()
            ));
            markInvestigatingBtn.setEnabled(true);
            markResolvedBtn.setEnabled(true);
            markReopenedBtn.setEnabled(true);
        }
    }

    private void applyStatusToSelected(String newStatus) {
        int selectedRow = adminTable.getSelectedRow();
        if (selectedRow == -1) return;

        String issueId = (String) adminTable.getValueAt(selectedRow, 0);
        Issue issue = DataStore.getInstance().findIssueById(issueId);

        if (issue != null) {
            issue.setStatus(newStatus);
            loadTableData();

            if (parentDashboard != null) {
                parentDashboard.refreshDashboardData();
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Status successfully updated to: " + newStatus + "\nIssue ID: " + issueId,
                    "Status Updated",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void loadTableData() {
        DataStore store = DataStore.getInstance();
        List<Issue> issues = store.getAllIssues();

        String selectedCat = (String) categoryFilterCombo.getSelectedItem();
        String selectedStatus = (String) statusFilterCombo.getSelectedItem();

        int total = issues.size();
        int reported = 0;
        int verified = 0;
        int resolved = 0;

        tableModel.setRowCount(0);

        for (Issue issue : issues) {
            String s = issue.getStatus().toUpperCase();
            if (s.contains("REPORTED")) reported++;
            if (s.contains("CLASS VERIFIED") || issue.isClassVerified()) verified++;
            if (s.contains("RESOLVED")) resolved++;

            boolean matchCat = "All Categories".equals(selectedCat) || issue.getCategory().equalsIgnoreCase(selectedCat);
            boolean matchStatus = "All Statuses".equals(selectedStatus) || issue.getStatus().equalsIgnoreCase(selectedStatus);

            if (matchCat && matchStatus) {
                String verificationRate = String.format("%.0f%% (%d votes)", issue.getFrequentlyPercentage() + issue.getSometimesPercentage(), issue.getTotalVotes());
                tableModel.addRow(new Object[]{
                        issue.getIssueId(),
                        issue.getCategory(),
                        issue.getTitle(),
                        issue.getDate(),
                        verificationRate,
                        issue.getStatus()
                });
            }
        }

        totalCountLabel.setText(String.valueOf(total));
        reportedCountLabel.setText(String.valueOf(reported));
        verifiedCountLabel.setText(String.valueOf(verified));
        resolvedCountLabel.setText(String.valueOf(resolved));

        updateSelectedIssueDisplay();
    }

    private void performAdminLogout() {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to log out from Administrative Dashboard?",
                "Confirm Admin Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (confirm == JOptionPane.YES_OPTION) {
            new LoginFrame().setVisible(true);
            this.dispose();
        }
    }
}
