package campusvoice.ui;

import campusvoice.model.Issue;
import campusvoice.model.Student;
import campusvoice.utils.DataStore;
import campusvoice.utils.UIUtils;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Modern Interactive StudentDashboard for CampusVoice.
 * Includes student avatar badge, 1-click token actions, interactive metric filters,
 * live search bar for recent issues, and 1-click tracking transitions.
 */
public class StudentDashboard extends JFrame {

    private JLabel tokenStatusBadge;
    private JLabel totalIssuesLabel;
    private JLabel underVerificationLabel;
    private JLabel resolvedLabel;
    private JTable recentIssuesTable;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private JTextField searchFilterField;

    public StudentDashboard() {
        setTitle("CampusVoice - Student Portal Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(960, 740);
        setMinimumSize(new Dimension(860, 620));
        setLocationRelativeTo(null);

        initComponents();
        refreshDashboardData();
    }

    private void initComponents() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UIUtils.COLOR_BG);

        Student student = DataStore.getInstance().getCurrentStudent();

        // 1. Top Modern Header Bar
        JPanel topBar = new JPanel(new BorderLayout(15, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(15, 23, 42),
                        getWidth(), getHeight(), new Color(30, 58, 138)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        topBar.setBorder(new EmptyBorder(16, 24, 16, 24));

        // Left Student Avatar & Info Block
        JPanel profileBlock = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        profileBlock.setOpaque(false);

        // Circular Avatar Initials
        JLabel avatarLabel = new JLabel("YR", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UIUtils.COLOR_PRIMARY);
                g2.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.setColor(Color.WHITE);
                g2.drawOval(0, 0, getWidth() - 1, getHeight() - 1);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        avatarLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        avatarLabel.setForeground(Color.WHITE);
        avatarLabel.setPreferredSize(new Dimension(46, 46));

        JPanel nameBlock = new JPanel();
        nameBlock.setLayout(new BoxLayout(nameBlock, BoxLayout.Y_AXIS));
        nameBlock.setOpaque(false);

        JLabel appTitle = new JLabel("CampusVoice Student Portal");
        appTitle.setFont(UIUtils.FONT_TITLE);
        appTitle.setForeground(Color.WHITE);

        JLabel studentInfo = new JLabel(
                student.getName() + " (" + student.getRollNumber() + ") • " +
                        student.getDepartment() + " (Sec " + student.getSection() + ")"
        );
        studentInfo.setFont(UIUtils.FONT_REGULAR);
        studentInfo.setForeground(new Color(224, 231, 255));

        JLabel collegeInfo = new JLabel(student.getCollege() + " (RTU Kota)");
        collegeInfo.setFont(UIUtils.FONT_SMALL);
        collegeInfo.setForeground(new Color(199, 210, 254));

        nameBlock.add(appTitle);
        nameBlock.add(Box.createVerticalStrut(2));
        nameBlock.add(studentInfo);
        nameBlock.add(Box.createVerticalStrut(1));
        nameBlock.add(collegeInfo);

        profileBlock.add(avatarLabel);
        profileBlock.add(nameBlock);

        JButton logoutBtn = UIUtils.createDangerButton("Logout");
        logoutBtn.addActionListener(e -> performLogout());

        topBar.add(profileBlock, BorderLayout.WEST);
        topBar.add(logoutBtn, BorderLayout.EAST);
        rootPanel.add(topBar, BorderLayout.NORTH);

        // 2. Main Scrollable Content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(UIUtils.COLOR_BG);
        contentPanel.setBorder(new EmptyBorder(18, 24, 20, 24));

        // Daily Voting Token Card
        JPanel tokenCard = createDailyTokenCard();
        contentPanel.add(tokenCard);
        contentPanel.add(Box.createVerticalStrut(16));

        // Quick Metrics Row (Interactive filters)
        JPanel statsRow = createStatsRow();
        contentPanel.add(statsRow);
        contentPanel.add(Box.createVerticalStrut(16));

        // Module Navigation Action Grid
        JPanel actionSection = createActionGrid();
        contentPanel.add(actionSection);
        contentPanel.add(Box.createVerticalStrut(18));

        // Recent Issues Table Card with Live Search
        JPanel tableCard = createRecentIssuesCard();
        contentPanel.add(tableCard);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(14);
        rootPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(rootPanel);
    }

    private JPanel createDailyTokenCard() {
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BorderLayout(15, 10));

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        JLabel heading = new JLabel("Daily Verification Token (Privacy Shield)");
        heading.setFont(UIUtils.FONT_SUBTITLE);
        heading.setForeground(UIUtils.COLOR_TEXT_MAIN);

        JLabel desc = new JLabel(
                "Authorizes 1 anonymous vote per issue without attaching your student identity."
        );
        desc.setFont(UIUtils.FONT_SMALL);
        desc.setForeground(UIUtils.COLOR_TEXT_MUTED);

        left.add(heading);
        left.add(Box.createVerticalStrut(4));
        left.add(desc);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);

        JLabel tokenBadge = new JLabel(" " + DataStore.DEMO_TOKEN + " ", SwingConstants.CENTER);
        tokenBadge.setFont(UIUtils.FONT_MONO);
        tokenBadge.setForeground(UIUtils.COLOR_PRIMARY);
        tokenBadge.setBackground(new Color(239, 246, 255));
        tokenBadge.setOpaque(true);
        tokenBadge.setBorder(new CompoundBorder(
                new LineBorder(new Color(191, 219, 254), 1, true),
                new EmptyBorder(6, 12, 6, 12)
        ));

        tokenStatusBadge = UIUtils.createStatusBadge("ACTIVE");

        JButton voteNowBtn = UIUtils.createPrimaryButton("Vote with Token");
        voteNowBtn.setToolTipText("Open verification screen with token ready");
        voteNowBtn.addActionListener(e -> new VerificationFrame(this).setVisible(true));

        JButton resetTokenBtn = UIUtils.createSecondaryButton("Reset Token (Demo)");
        resetTokenBtn.setToolTipText("Reset token state to VALID for presentation demo");
        resetTokenBtn.addActionListener(e -> {
            DataStore.getInstance().resetDemoToken();
            refreshDashboardData();
            JOptionPane.showMessageDialog(this, "Daily Token reset to ACTIVE state.", "Demo Control", JOptionPane.INFORMATION_MESSAGE);
        });

        right.add(new JLabel("Your Token:"));
        right.add(tokenBadge);
        right.add(tokenStatusBadge);
        right.add(voteNowBtn);
        right.add(resetTokenBtn);

        card.add(left, BorderLayout.WEST);
        card.add(right, BorderLayout.EAST);
        return card;
    }

    private JPanel createStatsRow() {
        JPanel row = new JPanel(new GridLayout(1, 3, 14, 0));
        row.setOpaque(false);

        totalIssuesLabel = new JLabel("0", SwingConstants.CENTER);
        underVerificationLabel = new JLabel("0", SwingConstants.CENTER);
        resolvedLabel = new JLabel("0", SwingConstants.CENTER);

        JPanel card1 = createStatCard("Total Reported Issues (Click to show all)", totalIssuesLabel, UIUtils.COLOR_PRIMARY);
        JPanel card2 = createStatCard("Under Active Verification (Click to filter)", underVerificationLabel, UIUtils.COLOR_WARNING);
        JPanel card3 = createStatCard("Resolved Issues (Click to filter)", resolvedLabel, UIUtils.COLOR_SUCCESS);

        // Interactive Filtering on Card Click
        card1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (rowSorter != null) rowSorter.setRowFilter(null);
                searchFilterField.setText("");
            }
        });
        card2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (rowSorter != null) rowSorter.setRowFilter(RowFilter.regexFilter("(?i)VERIFICATION"));
            }
        });
        card3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (rowSorter != null) rowSorter.setRowFilter(RowFilter.regexFilter("(?i)RESOLVED"));
            }
        });

        row.add(card1);
        row.add(card2);
        row.add(card3);

        return row;
    }

    private JPanel createStatCard(String title, JLabel valueLabel, Color accentColor) {
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BorderLayout(5, 5));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(UIUtils.FONT_SMALL);
        titleLbl.setForeground(UIUtils.COLOR_TEXT_MUTED);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        valueLabel.setForeground(accentColor);

        card.add(titleLbl, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private JPanel createActionGrid() {
        JPanel container = new JPanel(new BorderLayout());
        container.setOpaque(false);

        JLabel sectionTitle = new JLabel("Quick Actions & Student Modules");
        sectionTitle.setFont(UIUtils.FONT_SUBTITLE);
        sectionTitle.setForeground(UIUtils.COLOR_TEXT_MAIN);
        container.add(sectionTitle, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(1, 4, 14, 0));
        grid.setOpaque(false);
        grid.setBorder(new EmptyBorder(10, 0, 0, 0));

        grid.add(createModuleCard("Report Issue", "Submit anonymous campus issue with file proof.", "Report Issue", e -> {
            new IssueReportFrame(this).setVisible(true);
        }));

        grid.add(createModuleCard("Verify Issue", "Use daily token to vote on classmate issues.", "Verify Issue", e -> {
            new VerificationFrame(this).setVisible(true);
        }));

        grid.add(createModuleCard("Track Issue", "Search by Issue ID and inspect live milestone progress.", "Track Issue", e -> {
            new TrackingFrame(this).setVisible(true);
        }));

        grid.add(createModuleCard("Re-verification", "Provide post-resolution student feedback.", "Re-verification", e -> {
            new ReVerificationFrame(this).setVisible(true);
        }));

        container.add(grid, BorderLayout.CENTER);
        return container;
    }

    private JPanel createModuleCard(String title, String description, String buttonText, java.awt.event.ActionListener action) {
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BorderLayout(8, 8));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(UIUtils.FONT_BOLD);
        titleLbl.setForeground(UIUtils.COLOR_TEXT_MAIN);

        JLabel descLbl = new JLabel("<html>" + description + "</html>");
        descLbl.setFont(UIUtils.FONT_SMALL);
        descLbl.setForeground(UIUtils.COLOR_TEXT_MUTED);

        JButton actionBtn = UIUtils.createPrimaryButton(buttonText);
        actionBtn.addActionListener(action);

        card.add(titleLbl, BorderLayout.NORTH);
        card.add(descLbl, BorderLayout.CENTER);
        card.add(actionBtn, BorderLayout.SOUTH);
        return card;
    }

    private JPanel createRecentIssuesCard() {
        JPanel card = UIUtils.createCardPanel();
        card.setLayout(new BorderLayout(8, 10));

        JPanel topBar = new JPanel(new BorderLayout(10, 0));
        topBar.setOpaque(false);

        JLabel title = new JLabel("Recent Issues (Double-click any row to track)");
        title.setFont(UIUtils.FONT_SUBTITLE);
        title.setForeground(UIUtils.COLOR_TEXT_MAIN);

        // Search Input Filter Field
        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);

        JLabel searchIcon = new JLabel("Filter:");
        searchIcon.setFont(UIUtils.FONT_BOLD);

        searchFilterField = UIUtils.createTextField();
        searchFilterField.setPreferredSize(new Dimension(200, 32));
        searchFilterField.setToolTipText("Type issue ID, category or title to filter live");

        searchFilterField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { applyFilter(); }
            @Override
            public void removeUpdate(DocumentEvent e) { applyFilter(); }
            @Override
            public void changedUpdate(DocumentEvent e) { applyFilter(); }

            private void applyFilter() {
                String text = searchFilterField.getText().trim();
                if (text.isEmpty()) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });

        JButton refreshBtn = UIUtils.createSecondaryButton("Refresh");
        refreshBtn.addActionListener(e -> refreshDashboardData());

        searchBox.add(searchIcon);
        searchBox.add(searchFilterField);
        searchBox.add(refreshBtn);

        topBar.add(title, BorderLayout.WEST);
        topBar.add(searchBox, BorderLayout.EAST);
        card.add(topBar, BorderLayout.NORTH);

        String[] columns = {"Issue ID", "Category", "Issue Title", "Reported Date", "Current Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        recentIssuesTable = new JTable(tableModel);
        recentIssuesTable.setFont(UIUtils.FONT_REGULAR);
        recentIssuesTable.setRowHeight(34);
        recentIssuesTable.getTableHeader().setFont(UIUtils.FONT_BOLD);
        recentIssuesTable.getTableHeader().setBackground(new Color(241, 245, 249));

        rowSorter = new TableRowSorter<>(tableModel);
        recentIssuesTable.setRowSorter(rowSorter);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        recentIssuesTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        recentIssuesTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        recentIssuesTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        recentIssuesTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);

        // Double-click row -> opens TrackingFrame with that issue pre-selected!
        recentIssuesTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = recentIssuesTable.getSelectedRow();
                    if (row != -1) {
                        String id = (String) recentIssuesTable.getValueAt(row, 0);
                        TrackingFrame trackingFrame = new TrackingFrame(StudentDashboard.this);
                        trackingFrame.setPrefilledIssueId(id);
                        trackingFrame.setVisible(true);
                    }
                }
            }
        });

        recentIssuesTable.setFillsViewportHeight(true);

        JScrollPane scroll = new JScrollPane(recentIssuesTable);
        scroll.setPreferredSize(new Dimension(880, 200));
        scroll.setBorder(new LineBorder(UIUtils.COLOR_BORDER, 1, true));
        card.add(scroll, BorderLayout.CENTER);

        return card;
    }

    public void refreshDashboardData() {
        DataStore store = DataStore.getInstance();
        List<Issue> issues = store.getAllIssues();

        int total = issues.size();
        int underVerification = 0;
        int resolved = 0;

        for (Issue issue : issues) {
            String s = issue.getStatus().toUpperCase();
            if (s.contains("VERIFICATION") || s.contains("VERIFIED")) {
                underVerification++;
            }
            if (s.contains("RESOLVED")) {
                resolved++;
            }
        }

        totalIssuesLabel.setText(String.valueOf(total));
        underVerificationLabel.setText(String.valueOf(underVerification));
        resolvedLabel.setText(String.valueOf(resolved));

        // Update token badge
        if (store.isDemoTokenUsed()) {
            tokenStatusBadge.setText("USED");
            tokenStatusBadge.setForeground(UIUtils.COLOR_DANGER);
        } else {
            tokenStatusBadge.setText("ACTIVE");
            tokenStatusBadge.setForeground(UIUtils.COLOR_SUCCESS);
        }

        tableModel.setRowCount(0);
        for (Issue issue : issues) {
            tableModel.addRow(new Object[]{
                    issue.getIssueId(),
                    issue.getCategory(),
                    issue.getTitle(),
                    issue.getDate(),
                    issue.getStatus()
            });
        }
    }

    private void performLogout() {
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to log out from Student Portal?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
        if (confirm == JOptionPane.YES_OPTION) {
            new LoginFrame().setVisible(true);
            this.dispose();
        }
    }
}
