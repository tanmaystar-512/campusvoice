package campusvoice.utils;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/**
 * Modern Design System & Interactive UI Component Engine for CampusVoice.
 * Implements smooth antialiasing, rounded corners, interactive hover/pressed effects,
 * focus highlights, and responsive styled components.
 */
public class UIUtils {

    // Modern Palette
    public static final Color COLOR_PRIMARY = new Color(37, 99, 235);        // Royal Blue (#2563EB)
    public static final Color COLOR_PRIMARY_HOVER = new Color(29, 78, 216);  // Deep Blue (#1D4ED8)
    public static final Color COLOR_PRIMARY_DARK = new Color(30, 58, 138);   // Dark Slate Navy (#1E3A8A)
    public static final Color COLOR_HEADER_BG = new Color(15, 23, 42);       // Midnight Navy (#0F172A)

    public static final Color COLOR_ACCENT = new Color(14, 165, 233);        // Cyan/Sky Blue (#0EA5E9)
    public static final Color COLOR_BG = new Color(248, 250, 252);            // Clean Slate Off-White (#F8FAFC)
    public static final Color COLOR_CARD = Color.WHITE;
    public static final Color COLOR_BORDER = new Color(226, 232, 240);        // Subtle Border (#E2E8F0)
    public static final Color COLOR_BORDER_FOCUS = new Color(59, 130, 246);  // Focus Border Glow (#3B82F6)

    public static final Color COLOR_TEXT_MAIN = new Color(15, 23, 42);        // Slate 900 (#0F172A)
    public static final Color COLOR_TEXT_MUTED = new Color(100, 116, 139);    // Slate 500 (#64748B)

    public static final Color COLOR_SUCCESS = new Color(16, 185, 129);       // Emerald (#10B981)
    public static final Color COLOR_WARNING = new Color(245, 158, 11);       // Amber (#F59E0B)
    public static final Color COLOR_DANGER = new Color(239, 68, 68);         // Crimson (#EF4444)

    // Typography
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.BOLD, 15);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_MONO = new Font("Consolas", Font.BOLD, 14);

    /**
     * Interactive rounded button with smooth hover and click transitions.
     */
    public static JButton createPrimaryButton(String text) {
        return new ModernButton(text, COLOR_PRIMARY, COLOR_PRIMARY_HOVER, Color.WHITE);
    }

    public static JButton createSecondaryButton(String text) {
        return new ModernButton(text, Color.WHITE, new Color(241, 245, 249), COLOR_TEXT_MAIN, COLOR_BORDER);
    }

    public static JButton createSuccessButton(String text) {
        return new ModernButton(text, COLOR_SUCCESS, new Color(5, 150, 105), Color.WHITE);
    }

    public static JButton createDangerButton(String text) {
        return new ModernButton(text, COLOR_DANGER, new Color(220, 38, 38), Color.WHITE);
    }

    /**
     * Interactive text field with focus-glow outline.
     */
    public static JTextField createTextField() {
        JTextField tf = new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        tf.setOpaque(false);
        tf.setFont(FONT_REGULAR);
        tf.setForeground(COLOR_TEXT_MAIN);
        applyFieldFocusBorder(tf);
        return tf;
    }

    public static JPasswordField createPasswordField() {
        JPasswordField pf = new JPasswordField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        pf.setOpaque(false);
        pf.setFont(FONT_REGULAR);
        pf.setForeground(COLOR_TEXT_MAIN);
        applyFieldFocusBorder(pf);
        return pf;
    }

    private static void applyFieldFocusBorder(JComponent comp) {
        Border normalBorder = new CompoundBorder(
                new LineBorder(COLOR_BORDER, 1, true),
                new EmptyBorder(8, 12, 8, 12)
        );
        Border focusBorder = new CompoundBorder(
                new LineBorder(COLOR_BORDER_FOCUS, 2, true),
                new EmptyBorder(7, 11, 7, 11)
        );

        comp.setBorder(normalBorder);
        comp.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                comp.setBorder(focusBorder);
                comp.repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                comp.setBorder(normalBorder);
                comp.repaint();
            }
        });
    }

    /**
     * Modern card panel with rounded corners and subtle border.
     */
    public static JPanel createCardPanel() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_CARD);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
                g2.setColor(COLOR_BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(18, 22, 18, 22));
        return card;
    }

    /**
     * Modern header with dark navy gradient feel and icon badge.
     */
    public static JPanel createHeader(String title, String subtitle) {
        JPanel panel = new JPanel(new BorderLayout(15, 6)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(15, 23, 42),
                        getWidth(), getHeight(), new Color(30, 58, 138)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        panel.setBorder(new EmptyBorder(18, 24, 18, 24));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(FONT_TITLE);
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(FONT_REGULAR);
        subLbl.setForeground(new Color(224, 231, 255));

        panel.add(titleLbl, BorderLayout.NORTH);
        panel.add(subLbl, BorderLayout.SOUTH);
        return panel;
    }

    /**
     * Rounded Pill Status Badge with high contrast.
     */
    public static JLabel createStatusBadge(String status) {
        JLabel badge = new JLabel("  " + status + "  ", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                g2.setColor(getForeground());
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        badge.setOpaque(false);
        badge.setFont(FONT_BOLD);

        Color bg;
        Color fg;

        switch (status.toUpperCase()) {
            case "CLASS VERIFIED":
                bg = new Color(209, 250, 229);
                fg = new Color(4, 120, 87);
                break;
            case "UNDER VERIFICATION":
                bg = new Color(254, 243, 199);
                fg = new Color(180, 83, 9);
                break;
            case "RESOLVED":
                bg = new Color(219, 234, 254);
                fg = new Color(29, 78, 216);
                break;
            case "REOPENED":
                bg = new Color(254, 226, 226);
                fg = new Color(185, 28, 28);
                break;
            case "UNDER INVESTIGATION":
                bg = new Color(243, 232, 255);
                fg = new Color(126, 34, 206);
                break;
            case "REPORTED":
            default:
                bg = new Color(241, 245, 249);
                fg = COLOR_TEXT_MUTED;
                break;
        }

        badge.setBackground(bg);
        badge.setForeground(fg);
        badge.setBorder(new EmptyBorder(5, 12, 5, 12));
        return badge;
    }

    /**
     * Modern percentage progress bar with custom color fill.
     */
    public static JProgressBar createProgressBar(int value, Color barColor) {
        JProgressBar pb = new JProgressBar(0, 100);
        pb.setValue(value);
        pb.setStringPainted(true);
        pb.setFont(FONT_BOLD);
        pb.setForeground(barColor);
        pb.setBackground(new Color(241, 245, 249));
        pb.setBorder(new LineBorder(COLOR_BORDER, 1, true));
        pb.setPreferredSize(new Dimension(160, 22));
        return pb;
    }

    // Custom Rounded Interactive Button Implementation
    public static class ModernButton extends JButton {
        private final Color normalColor;
        private final Color hoverColor;
        private Color borderColor = null;
        private boolean isHovered = false;

        public ModernButton(String text, Color normal, Color hover, Color fg) {
            super(text);
            this.normalColor = normal;
            this.hoverColor = hover;
            init(fg);
        }

        public ModernButton(String text, Color normal, Color hover, Color fg, Color border) {
            super(text);
            this.normalColor = normal;
            this.hoverColor = hover;
            this.borderColor = border;
            init(fg);
        }

        private void init(Color fg) {
            setFont(FONT_BOLD);
            setForeground(fg);
            setFocusPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setBorder(new EmptyBorder(10, 20, 10, 20));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    if (isEnabled()) {
                        isHovered = true;
                        repaint();
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            Color currentBg = isHovered ? hoverColor : normalColor;
            g2.setColor(currentBg);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);

            if (borderColor != null) {
                g2.setColor(isHovered ? COLOR_BORDER_FOCUS : borderColor);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
            }

            super.paintComponent(g);
            g2.dispose();
        }
    }
}
