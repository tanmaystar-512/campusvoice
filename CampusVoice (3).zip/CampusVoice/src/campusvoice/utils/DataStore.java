package campusvoice.utils;

import campusvoice.model.Issue;
import campusvoice.model.Student;

import java.util.*;

/**
 * In-memory repository for prototype state management.
 * Avoids direct database dependencies while ensuring live cross-screen updates.
 * Manages registered students, student authentication, and dynamic daily tokens.
 */
public class DataStore {

    private static DataStore instance;

    private final List<Issue> issues;
    private final Map<String, Student> registeredStudents;
    private final Map<String, String> studentPasswords;
    private Student currentStudent;
    private final Random random;

    // Daily Token System (Demo token configured for Yash Raj: CV1832026)
    public static final String DEMO_TOKEN = "CV1832026";
    private boolean isDemoTokenUsed = false;

    private DataStore() {
        this.issues = new ArrayList<>();
        this.registeredStudents = new HashMap<>();
        this.studentPasswords = new HashMap<>();
        this.random = new Random();

        // Register default student: Yash Raj
        Student defaultStudent = new Student(
                "183",
                "Yash Raj",
                "24EARAD183",
                "B.Tech Artificial Intelligence & Data Science",
                "C",
                "Arya College of Engineering & IT, Jaipur"
        );
        this.registeredStudents.put("183", defaultStudent);
        this.studentPasswords.put("183", "1234");
        this.currentStudent = defaultStudent;

        seedInitialIssues();
    }

    public static synchronized DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }

    private void seedInitialIssues() {
        issues.add(new Issue(
                "CV-1847",
                "Classroom",
                "Air Conditioner malfunction in Room 304 (C-Block)",
                "The split AC unit makes loud grinding noise and cooling cuts out after 10 minutes of lecture.",
                "evidence_room304.jpg",
                "2026-10-07",
                "REPORTED"
        ));

        issues.add(new Issue(
                "CV-4821",
                "Laboratory",
                "GPU workstations rebooting during PyTorch model training in AI Lab 2",
                "Systems 14 to 22 experience kernel panics and black screens under GPU load. Pending class voting.",
                "crash_log.png",
                "2026-10-08",
                "UNDER VERIFICATION",
                28, 8, 2
        ));

        Issue resolvedIssue = new Issue(
                "CV-7392",
                "Other",
                "Water dispenser RO filter replacement required on 2nd Floor",
                "Water pressure low and TDS indicator blinking red near Department office.",
                "",
                "2026-10-05",
                "RESOLVED",
                32, 10, 1
        );
        issues.add(resolvedIssue);

        issues.add(new Issue(
                "CV-2950",
                "Canteen",
                "Digital payment terminal QR code scanner damaged",
                "Students experiencing long queue bottlenecks during short breaks due to cash-only transactions.",
                "",
                "2026-10-09",
                "REPORTED"
        ));
    }

    public synchronized boolean isStudentIdRegistered(String id) {
        if (id == null) return false;
        return registeredStudents.containsKey(id.trim());
    }

    public synchronized boolean registerStudent(String studentId, String password, String name,
                                                String rollNo, String dept, String section) {
        if (studentId == null || password == null || isStudentIdRegistered(studentId)) {
            return false;
        }

        String cleanId = studentId.trim();
        Student newStudent = new Student(
                cleanId,
                name.trim(),
                rollNo.trim(),
                dept.trim(),
                section.trim(),
                "Arya College of Engineering & IT, Jaipur"
        );

        registeredStudents.put(cleanId, newStudent);
        studentPasswords.put(cleanId, password.trim());
        return true;
    }

    public synchronized Student authenticateStudent(String studentId, String password) {
        if (studentId == null || password == null) return null;
        String cleanId = studentId.trim();
        String storedPass = studentPasswords.get(cleanId);
        if (storedPass != null && storedPass.equals(password.trim())) {
            this.currentStudent = registeredStudents.get(cleanId);
            return this.currentStudent;
        }
        return null;
    }

    public synchronized String generateIssueId() {
        String newId;
        do {
            int code = 1000 + random.nextInt(9000);
            newId = "CV-" + code;
        } while (findIssueById(newId) != null);
        return newId;
    }

    public synchronized void addIssue(Issue issue) {
        issues.add(0, issue);
    }

    public synchronized Issue findIssueById(String issueId) {
        if (issueId == null) return null;
        String cleanId = issueId.trim().toUpperCase();
        for (Issue issue : issues) {
            if (issue.getIssueId().equalsIgnoreCase(cleanId)) {
                return issue;
            }
        }
        return null;
    }

    public synchronized List<Issue> getAllIssues() {
        return Collections.unmodifiableList(new ArrayList<>(issues));
    }

    public synchronized Student getCurrentStudent() {
        return currentStudent;
    }

    public synchronized void setCurrentStudent(Student student) {
        this.currentStudent = student;
    }

    public synchronized String validateToken(String tokenInput) {
        if (tokenInput == null || tokenInput.trim().isEmpty()) {
            return "INVALID";
        }
        String clean = tokenInput.trim();
        if (!clean.equalsIgnoreCase(DEMO_TOKEN)) {
            return "INVALID";
        }
        if (isDemoTokenUsed) {
            return "USED";
        }
        return "VALID";
    }

    public synchronized void consumeDemoToken() {
        this.isDemoTokenUsed = true;
    }

    public synchronized void resetDemoToken() {
        this.isDemoTokenUsed = false;
    }

    public synchronized boolean isDemoTokenUsed() {
        return isDemoTokenUsed;
    }
}
