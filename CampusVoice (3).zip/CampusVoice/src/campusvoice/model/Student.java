package campusvoice.model;

/**
 * Represents a student user in the CampusVoice system.
 * Contains student identification details used for authentication and dashboard display.
 */
public class Student {
    private final String studentId;
    private final String name;
    private final String rollNumber;
    private final String department;
    private final String section;
    private final String college;

    public Student(String studentId, String name, String rollNumber, String department, String section, String college) {
        this.studentId = studentId;
        this.name = name;
        this.rollNumber = rollNumber;
        this.department = department;
        this.section = section;
        this.college = college;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public String getDepartment() {
        return department;
    }

    public String getSection() {
        return section;
    }

    public String getCollege() {
        return college;
    }
}
