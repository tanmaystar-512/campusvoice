package campusvoice.model;

/**
 * Represents an issue reported within CampusVoice.
 * Tracks issue metadata, class-level verification voting tallies,
 * and post-resolution re-verification feedback.
 */
public class Issue {
    private final String issueId;
    private final String category;
    private final String title;
    private final String description;
    private final String evidencePath;
    private final String date;
    private String status;

    // Voting counts (Class-level verification)
    private int votesFrequently;
    private int votesSometimes;
    private int votesNever;

    // Re-verification feedback counts
    private int reVerifyResolved;
    private int reVerifyPartially;
    private int reVerifyStillFacing;

    // Configurable thresholds for verification
    public static final double MIN_PARTICIPATION_THRESHOLD = 30.0; // 30% minimum class participation
    public static final double CONFIRMATION_THRESHOLD = 60.0;     // 60% agreement for verification
    public static final int ESTIMATED_CLASS_SIZE = 60;             // Reference cohort size

    public Issue(String issueId, String category, String title, String description,
                 String evidencePath, String date, String status) {
        this.issueId = issueId;
        this.category = category;
        this.title = title;
        this.description = description;
        this.evidencePath = evidencePath != null ? evidencePath : "";
        this.date = date;
        this.status = status;
        this.votesFrequently = 0;
        this.votesSometimes = 0;
        this.votesNever = 0;
        this.reVerifyResolved = 0;
        this.reVerifyPartially = 0;
        this.reVerifyStillFacing = 0;
    }

    public Issue(String issueId, String category, String title, String description,
                 String evidencePath, String date, String status,
                 int frequently, int sometimes, int never) {
        this(issueId, category, title, description, evidencePath, date, status);
        this.votesFrequently = frequently;
        this.votesSometimes = sometimes;
        this.votesNever = never;
    }

    public String getIssueId() {
        return issueId;
    }

    public String getCategory() {
        return category;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getEvidencePath() {
        return evidencePath;
    }

    public String getDate() {
        return date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public synchronized void recordVote(String option) {
        if ("Frequently".equalsIgnoreCase(option)) {
            votesFrequently++;
        } else if ("Sometimes".equalsIgnoreCase(option)) {
            votesSometimes++;
        } else if ("Never".equalsIgnoreCase(option)) {
            votesNever++;
        }
        updateVerificationStatus();
    }

    public synchronized void recordReVerification(String feedback) {
        if ("Resolved".equalsIgnoreCase(feedback)) {
            reVerifyResolved++;
        } else if ("Partially Resolved".equalsIgnoreCase(feedback)) {
            reVerifyPartially++;
        } else if ("Still Facing Problem".equalsIgnoreCase(feedback)) {
            reVerifyStillFacing++;
            // If significant students still face problem, auto-flag for reopening
            if (reVerifyStillFacing >= 2 && "RESOLVED".equalsIgnoreCase(status)) {
                this.status = "REOPENED";
            }
        }
    }

    public int getTotalVotes() {
        return votesFrequently + votesSometimes + votesNever;
    }

    public double getFrequentlyPercentage() {
        int total = getTotalVotes();
        return total == 0 ? 0.0 : Math.round(((double) votesFrequently / total) * 100.0);
    }

    public double getSometimesPercentage() {
        int total = getTotalVotes();
        return total == 0 ? 0.0 : Math.round(((double) votesSometimes / total) * 100.0);
    }

    public double getNeverPercentage() {
        int total = getTotalVotes();
        return total == 0 ? 0.0 : Math.round(((double) votesNever / total) * 100.0);
    }

    public double getParticipationRate() {
        return Math.min(100.0, Math.round(((double) getTotalVotes() / ESTIMATED_CLASS_SIZE) * 100.0));
    }

    public boolean isClassVerified() {
        // Confirmation is based on students who experienced it (Frequently + Sometimes)
        double experiencedPct = getFrequentlyPercentage() + getSometimesPercentage();
        return getParticipationRate() >= MIN_PARTICIPATION_THRESHOLD && experiencedPct >= CONFIRMATION_THRESHOLD;
    }

    public void updateVerificationStatus() {
        if ("REPORTED".equalsIgnoreCase(status) || "UNDER VERIFICATION".equalsIgnoreCase(status)) {
            if (isClassVerified()) {
                this.status = "CLASS VERIFIED";
            } else if (getTotalVotes() > 0) {
                this.status = "UNDER VERIFICATION";
            }
        }
    }

    public int getVotesFrequently() {
        return votesFrequently;
    }

    public int getVotesSometimes() {
        return votesSometimes;
    }

    public int getVotesNever() {
        return votesNever;
    }
}
