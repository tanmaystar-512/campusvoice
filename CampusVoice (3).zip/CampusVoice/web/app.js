/**
 * CampusVoice - Interactive Web Application Logic
 * Student: Yash Raj (24EARAD183) | Arya College of Engineering & IT (RTU Kota)
 * Core Logic: In-memory/localStorage state, Token Security, Class-Level Quorum, Real-time Search
 */

// -------------------------------------------------------------
// 1. Initial State & Data Store
// -------------------------------------------------------------
const ESTIMATED_CLASS_SIZE = 60;
const DEMO_TOKEN_CODE = "CV1832026";

const INITIAL_ISSUES = [
  {
    id: "CV-1847",
    category: "Classroom",
    title: "Air Conditioner malfunction in Room 304 (C-Block)",
    description: "The split AC unit makes loud grinding noise and cooling cuts out after 10 minutes of lecture.",
    evidence: "evidence_room304.jpg",
    date: "2026-10-07",
    status: "REPORTED",
    votes: { frequently: 4, sometimes: 2, never: 1 },
    reverify: { resolved: 0, partially: 0, stillFacing: 0 }
  },
  {
    id: "CV-4821",
    category: "Laboratory",
    title: "GPU workstations rebooting during PyTorch model training in AI Lab 2",
    description: "Systems 14 to 22 experience kernel panics and black screens under GPU load. Pending cohort verification voting.",
    evidence: "crash_log.png",
    date: "2026-10-08",
    status: "UNDER VERIFICATION",
    votes: { frequently: 28, sometimes: 8, never: 2 },
    reverify: { resolved: 0, partially: 0, stillFacing: 0 }
  },
  {
    id: "CV-7392",
    category: "Other",
    title: "Water dispenser RO filter replacement required on 2nd Floor",
    description: "Water pressure low and TDS indicator blinking red near Department office.",
    evidence: "",
    date: "2026-10-05",
    status: "RESOLVED",
    votes: { frequently: 32, sometimes: 10, never: 1 },
    reverify: { resolved: 8, partially: 1, stillFacing: 0 }
  },
  {
    id: "CV-2950",
    category: "Canteen",
    title: "Digital payment terminal QR code scanner damaged",
    description: "Students experiencing long queue bottlenecks during short breaks due to cash-only transactions.",
    evidence: "",
    date: "2026-10-09",
    status: "REPORTED",
    votes: { frequently: 6, sometimes: 1, never: 0 },
    reverify: { resolved: 0, partially: 0, stillFacing: 0 }
  }
];

// Default Students Registry
const INITIAL_STUDENTS = [
  {
    id: "183",
    password: "1234",
    name: "Yash Raj",
    roll: "24EARAD183",
    dept: "B.Tech Artificial Intelligence & Data Science",
    section: "C"
  }
];

// Load from LocalStorage or initialize
let issues = [];
try {
  const saved = localStorage.getItem("campusvoice_issues");
  issues = saved ? JSON.parse(saved) : JSON.parse(JSON.stringify(INITIAL_ISSUES));
} catch (e) {
  issues = JSON.parse(JSON.stringify(INITIAL_ISSUES));
}

let students = [];
try {
  const savedStudents = localStorage.getItem("campusvoice_students");
  students = savedStudents ? JSON.parse(savedStudents) : JSON.parse(JSON.stringify(INITIAL_STUDENTS));
} catch (e) {
  students = JSON.parse(JSON.stringify(INITIAL_STUDENTS));
}

let currentStudent = students[0];
let isTokenUsed = localStorage.getItem("campusvoice_token_used") === "true";
let currentUserRole = null; // 'student' | 'admin' | null
let selectedVoteOption = null;
let selectedReverifyOption = null;
let currentAdminSelectedId = null;
let currentTableFilterStatus = "ALL";

function saveState() {
  localStorage.setItem("campusvoice_issues", JSON.stringify(issues));
  localStorage.setItem("campusvoice_students", JSON.stringify(students));
  localStorage.setItem("campusvoice_token_used", isTokenUsed ? "true" : "false");
}

// -------------------------------------------------------------
// 2. Authentication & Navigation
// -------------------------------------------------------------
function switchAuthTab(role) {
  const tabStudent = document.getElementById("tab-student");
  const tabRegister = document.getElementById("tab-register");
  const tabAdmin = document.getElementById("tab-admin");
  const formStudent = document.getElementById("form-student-login");
  const formRegister = document.getElementById("form-student-register");
  const formAdmin = document.getElementById("form-admin-login");

  // Reset all tabs
  [tabStudent, tabRegister, tabAdmin].forEach(t => {
    t.className = "py-2.5 px-3 rounded-lg font-semibold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 text-slate-400 hover:text-white";
  });
  formStudent.classList.add("hidden");
  formRegister.classList.add("hidden");
  formAdmin.classList.add("hidden");

  if (role === "student") {
    tabStudent.className = "py-2.5 px-3 rounded-lg font-semibold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 bg-blue-600 text-white shadow-md";
    formStudent.classList.remove("hidden");
    document.getElementById("student-id").focus();
  } else if (role === "register") {
    tabRegister.className = "py-2.5 px-3 rounded-lg font-semibold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 bg-emerald-600 text-white shadow-md";
    formRegister.classList.remove("hidden");
    document.getElementById("reg-name").focus();
  } else {
    tabAdmin.className = "py-2.5 px-3 rounded-lg font-semibold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 bg-amber-600 text-white shadow-md";
    formAdmin.classList.remove("hidden");
    document.getElementById("admin-user").focus();
  }
}

function quickFillStudent() {
  document.getElementById("student-id").value = "183";
  document.getElementById("student-pass").value = "1234";
  showToast("Demo Auto-Fill", "Student credentials entered (183 / 1234)", "info");
}

function quickFillAdmin() {
  document.getElementById("admin-user").value = "admin";
  document.getElementById("admin-pass").value = "admin123";
  showToast("Demo Auto-Fill", "Admin credentials entered (admin / admin123)", "info");
}

function togglePassword(inputId, btn) {
  const input = document.getElementById(inputId);
  const icon = btn.querySelector("i");
  if (input.type === "password") {
    input.type = "text";
    icon.className = "fa-solid fa-eye-slash";
  } else {
    input.type = "password";
    icon.className = "fa-regular fa-eye";
  }
}

function handleStudentRegister(e) {
  e.preventDefault();
  const name = document.getElementById("reg-name").value.trim();
  const id = document.getElementById("reg-id").value.trim();
  const roll = document.getElementById("reg-roll").value.trim();
  const dept = document.getElementById("reg-dept").value;
  const sec = document.getElementById("reg-sec").value;
  const pass = document.getElementById("reg-pass").value.trim();
  const conf = document.getElementById("reg-conf").value.trim();

  if (!name) {
    showToast("Input Required", "Please enter your Full Name.", "warning");
    document.getElementById("reg-name").focus();
    return;
  }
  if (!id) {
    showToast("Input Required", "Please enter Student ID / Code.", "warning");
    document.getElementById("reg-id").focus();
    return;
  }
  if (!roll) {
    showToast("Input Required", "Please enter Roll Number.", "warning");
    document.getElementById("reg-roll").focus();
    return;
  }
  if (!pass || pass.length < 4) {
    showToast("Password Too Short", "Password must be at least 4 characters.", "warning");
    document.getElementById("reg-pass").focus();
    return;
  }
  if (pass !== conf) {
    showToast("Password Mismatch", "Passwords do not match. Please re-enter.", "error");
    document.getElementById("reg-conf").focus();
    return;
  }

  // Duplicate ID check
  if (students.some(s => s.id.toLowerCase() === id.toLowerCase())) {
    showToast("Already Registered", `Student ID "${id}" is already registered. Please login.`, "warning");
    return;
  }

  const newStudent = {
    id,
    password: pass,
    name,
    roll,
    dept,
    section: sec
  };

  students.push(newStudent);
  saveState();

  // Reset form
  document.getElementById("reg-name").value = "";
  document.getElementById("reg-id").value = "";
  document.getElementById("reg-roll").value = "";
  document.getElementById("reg-pass").value = "";
  document.getElementById("reg-conf").value = "";

  showToast("Account Created!", `Welcome ${name}! Please login with Student ID: ${id}`, "success");

  // Switch to Student Login and prefill ID
  switchAuthTab("student");
  document.getElementById("student-id").value = id;
  document.getElementById("student-pass").focus();
}

function handleStudentLogin(e) {
  e.preventDefault();
  const id = document.getElementById("student-id").value.trim();
  const pass = document.getElementById("student-pass").value.trim();

  if (!id) {
    showToast("Input Required", "Please enter your Student ID.", "warning");
    return;
  }
  if (!pass) {
    showToast("Input Required", "Please enter your Password.", "warning");
    return;
  }

  const student = students.find(s => s.id.toLowerCase() === id.toLowerCase() && s.password === pass);

  if (student) {
    currentStudent = student;
    currentUserRole = "student";
    document.getElementById("view-login").classList.add("hidden");
    document.getElementById("view-student").classList.remove("hidden");
    document.getElementById("view-admin").classList.add("hidden");

    updateStudentHeader(student);
    showToast(`Welcome ${student.name}`, `Student Portal authenticated (${student.roll}).`, "success");
    refreshDashboard();
  } else {
    showToast("Login Failed", "Invalid credentials. Use demo ID: 183 / Pass: 1234 or Register a new account.", "error");
  }
}

function updateStudentHeader(student) {
  const parts = student.name.split(" ");
  const initials = parts.length >= 2 ? (parts[0][0] + parts[1][0]).toUpperCase() : student.name.substring(0, 2).toUpperCase();

  const avatar = document.querySelector("#view-student header .w-12");
  if (avatar) avatar.textContent = initials;

  const nameEl = document.querySelector("#view-student header h2");
  if (nameEl) nameEl.textContent = student.name;

  const rollEl = document.querySelector("#view-student header span.border-blue-500\\/30");
  if (rollEl) rollEl.textContent = student.roll;

  const descEl = document.querySelector("#view-student header p.text-slate-400");
  if (descEl) descEl.textContent = `${student.dept} (Sec ${student.section}) • Arya College of Engg & IT (RTU)`;

  const tokenDisplay = document.getElementById("display-token-code");
  if (tokenDisplay) tokenDisplay.textContent = `CV${student.id}2026`;
}

function handleAdminLogin(e) {
  e.preventDefault();
  const user = document.getElementById("admin-user").value.trim();
  const pass = document.getElementById("admin-pass").value.trim();

  if (!user || !pass) {
    showToast("Input Required", "Please fill both Admin Username and Password.", "warning");
    return;
  }

  if (user.toLowerCase() === "admin" && pass === "admin123") {
    currentUserRole = "admin";
    document.getElementById("view-login").classList.add("hidden");
    document.getElementById("view-student").classList.add("hidden");
    document.getElementById("view-admin").classList.remove("hidden");
    showToast("Admin Access Granted", "Authority Review Dashboard loaded.", "success");
    renderAdminDashboard();
  } else {
    showToast("Login Failed", "Invalid credentials. Use Username: admin & Pass: admin123", "error");
  }
}

function logout() {
  currentUserRole = null;
  document.getElementById("view-student").classList.add("hidden");
  document.getElementById("view-admin").classList.add("hidden");
  document.getElementById("view-login").classList.remove("hidden");
  showToast("Logged Out", "Session terminated safely.", "info");
}

// -------------------------------------------------------------
// 3. Student Dashboard Metrics & Table
// -------------------------------------------------------------
function refreshDashboard() {
  renderTokenBadge();
  renderDashboardStats();
  renderRecentIssuesTable();
  populateVerifyModalIssues();
  populateReverifyModalIssues();
}

function renderTokenBadge() {
  const badge = document.getElementById("badge-token-status");
  if (isTokenUsed) {
    badge.className = "text-xs font-bold px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30";
    badge.textContent = "USED";
  } else {
    badge.className = "text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30";
    badge.textContent = "ACTIVE";
  }
}

function renderDashboardStats() {
  let underVerification = 0;
  let resolved = 0;

  issues.forEach(i => {
    const s = i.status.toUpperCase();
    if (s.includes("VERIFICATION") || s.includes("VERIFIED")) underVerification++;
    if (s.includes("RESOLVED")) resolved++;
  });

  document.getElementById("stat-total-issues").textContent = issues.length;
  document.getElementById("stat-under-verification").textContent = underVerification;
  document.getElementById("stat-resolved-issues").textContent = resolved;
}

function renderRecentIssuesTable() {
  const tbody = document.getElementById("table-issues-body");
  const searchInput = document.getElementById("input-search-issues").value.toLowerCase().trim();

  let filtered = issues.filter(issue => {
    // Status Filter
    if (currentTableFilterStatus === "VERIFICATION") {
      const s = issue.status.toUpperCase();
      if (!s.includes("VERIFICATION") && !s.includes("VERIFIED")) return false;
    } else if (currentTableFilterStatus === "RESOLVED") {
      if (issue.status.toUpperCase() !== "RESOLVED") return false;
    }

    // Text Search Filter
    if (searchInput) {
      const match = issue.id.toLowerCase().includes(searchInput) ||
                    issue.title.toLowerCase().includes(searchInput) ||
                    issue.category.toLowerCase().includes(searchInput);
      if (!match) return false;
    }
    return true;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="py-8 text-center text-slate-500">No matching issues found.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(issue => {
    const totalVotes = issue.votes.frequently + issue.votes.sometimes + issue.votes.never;
    const expPct = totalVotes === 0 ? 0 : Math.round(((issue.votes.frequently + issue.votes.sometimes) / totalVotes) * 100);

    return `
      <tr onclick="trackFromTable('${issue.id}')" class="hover:bg-slate-700/40 transition-colors cursor-pointer group">
        <td class="py-3 px-4 font-mono font-bold text-blue-400 group-hover:text-blue-300">${issue.id}</td>
        <td class="py-3 px-4 text-slate-300">${issue.category}</td>
        <td class="py-3 px-4 font-semibold text-white max-w-xs truncate">${issue.title}</td>
        <td class="py-3 px-4 text-slate-400">${issue.date}</td>
        <td class="py-3 px-4 text-slate-300">${expPct}% (${totalVotes} votes)</td>
        <td class="py-3 px-4">${renderStatusBadgeHTML(issue.status)}</td>
        <td class="py-3 px-4 text-right">
          <button onclick="event.stopPropagation(); trackFromTable('${issue.id}')" class="px-2.5 py-1 rounded-lg bg-slate-700 hover:bg-blue-600 text-slate-300 hover:text-white transition-all text-xs font-bold">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Track
          </button>
        </td>
      </tr>
    `;
  }).join("");
}

function filterTableByStatus(status) {
  currentTableFilterStatus = status;
  renderRecentIssuesTable();
  const label = status === "ALL" ? "All Issues" : (status === "VERIFICATION" ? "Under Verification" : "Resolved");
  showToast("Filter Applied", `Showing ${label} in table.`, "info");
}

function handleTableSearch() {
  renderRecentIssuesTable();
}

function trackFromTable(issueId) {
  document.getElementById("track-id-input").value = issueId;
  openModal("modal-track");
  performTrackLookup();
}

function renderStatusBadgeHTML(status) {
  const cleanClass = status.replace(/\s+/g, '_').toUpperCase();
  return `<span class="badge-status ${cleanClass}">${status}</span>`;
}

// -------------------------------------------------------------
// 4. Modal Controllers
// -------------------------------------------------------------
function openModal(id) {
  document.getElementById(id).classList.remove("hidden");
  if (id === "modal-verify") {
    document.getElementById("verify-token-input").value = isTokenUsed ? "" : DEMO_TOKEN_CODE;
    updateVerifyModalStats();
  }
}

function closeModal(id) {
  document.getElementById(id).classList.add("hidden");
}

// Close modal when clicking outside
window.addEventListener("click", (e) => {
  if (e.target.classList.contains("modal-overlay")) {
    e.target.classList.add("hidden");
  }
});

// -------------------------------------------------------------
// 5. Module: Report Issue
// -------------------------------------------------------------
function updateCategoryHint() {
  const cat = document.getElementById("report-category").value;
  const hint = document.getElementById("report-category-hint");
  const hints = {
    Classroom: "Classroom: Report issues with projectors, AC units, furniture, or smart boards.",
    Laboratory: "Laboratory: Report issues with GPU workstations, compiler software, instruments, or network.",
    Faculty: "Faculty: Confidential reporting on lecture scheduling, coverage, or academic guidance.",
    Hostel: "Hostel: Report issues with electricity, water supply, room maintenance, or mess.",
    Canteen: "Canteen: Report issues with food hygiene, pricing, digital payment scanner, or seating.",
    Administration: "Administration: Report fee counters, document issuance, scholarship desk, or transport.",
    Other: "Other: General campus facility concerns."
  };
  hint.textContent = hints[cat] || "Select an issue category.";
}

function updateCharCount(el) {
  const len = el.value.length;
  document.getElementById("report-char-count").textContent = `${len} / 500 characters`;
}

let attachedFileName = "";
function handleFileSelect(input) {
  if (input.files && input.files[0]) {
    const file = input.files[0];
    attachedFileName = file.name;
    document.getElementById("report-file-name").textContent = `${file.name} (${Math.round(file.size / 1024)} KB)`;
    document.getElementById("btn-remove-file").classList.remove("hidden");
  }
}

function removeSelectedFile() {
  attachedFileName = "";
  document.getElementById("report-file").value = "";
  document.getElementById("report-file-name").textContent = "No file selected";
  document.getElementById("btn-remove-file").classList.add("hidden");
}

function handleReportIssue(e) {
  e.preventDefault();
  const category = document.getElementById("report-category").value;
  const title = document.getElementById("report-title").value.trim();
  const desc = document.getElementById("report-desc").value.trim();

  if (!title) {
    showToast("Input Required", "Please enter Issue Title.", "warning");
    document.getElementById("report-title").focus();
    return;
  }
  if (!desc) {
    showToast("Input Required", "Please enter issue description.", "warning");
    document.getElementById("report-desc").focus();
    return;
  }

  // Generate unique CV-XXXX ID
  let newId;
  do {
    const rand = Math.floor(1000 + Math.random() * 9000);
    newId = `CV-${rand}`;
  } while (issues.some(i => i.id === newId));

  const today = new Date().toISOString().split("T")[0];

  const newIssue = {
    id: newId,
    category,
    title,
    description: desc,
    evidence: attachedFileName,
    date: today,
    status: "REPORTED",
    votes: { frequently: 0, sometimes: 0, never: 0 },
    reverify: { resolved: 0, partially: 0, stillFacing: 0 }
  };

  issues.unshift(newIssue);
  saveState();
  closeModal("modal-report");

  // Reset form
  document.getElementById("report-title").value = "";
  document.getElementById("report-desc").value = "";
  removeSelectedFile();
  document.getElementById("report-char-count").textContent = "0 / 500 characters";

  refreshDashboard();
  showToast("Issue Submitted!", `Generated Issue ID: ${newId}. Keep this ID to track progress.`, "success");

  // Automatically offer tracking
  setTimeout(() => {
    trackFromTable(newId);
  }, 400);
}

// -------------------------------------------------------------
// 6. Module: Verification Voting & Token System
// -------------------------------------------------------------
function pasteDailyToken() {
  document.getElementById("verify-token-input").value = DEMO_TOKEN_CODE;
  showToast("Token Pasted", "Active daily token CV1832026 inserted.", "info");
}

function populateVerifyModalIssues() {
  const select = document.getElementById("verify-issue-select");
  select.innerHTML = issues.map(i => `<option value="${i.id}">[${i.id}] ${i.title}</option>`).join("");
}

function selectVoteCard(option) {
  selectedVoteOption = option;
  ["Frequently", "Sometimes", "Never"].forEach(opt => {
    const card = document.getElementById(`vote-card-${opt}`);
    if (opt === option) {
      if (opt === "Frequently") card.className = "cursor-pointer p-4 rounded-xl card-selected-blue border-2 text-center";
      if (opt === "Sometimes") card.className = "cursor-pointer p-4 rounded-xl card-selected-amber border-2 text-center";
      if (opt === "Never") card.className = "cursor-pointer p-4 rounded-xl card-selected-slate border-2 text-center";
    } else {
      card.className = "cursor-pointer p-4 rounded-xl bg-slate-900/80 border-2 border-slate-700 hover:border-slate-500 transition-all text-center";
    }
  });
}

function updateVerifyModalStats() {
  const select = document.getElementById("verify-issue-select");
  const issueId = select.value;
  const issue = issues.find(i => i.id === issueId);
  if (!issue) return;

  const total = issue.votes.frequently + issue.votes.sometimes + issue.votes.never;
  const freqPct = total === 0 ? 0 : Math.round((issue.votes.frequently / total) * 100);
  const somePct = total === 0 ? 0 : Math.round((issue.votes.sometimes / total) * 100);
  const neverPct = total === 0 ? 0 : Math.round((issue.votes.never / total) * 100);
  const partPct = Math.min(100, Math.round((total / ESTIMATED_CLASS_SIZE) * 100));

  document.getElementById("verify-freq-val").textContent = `${freqPct}% (${issue.votes.frequently} votes)`;
  document.getElementById("verify-freq-bar").style.width = `${freqPct}%`;

  document.getElementById("verify-some-val").textContent = `${somePct}% (${issue.votes.sometimes} votes)`;
  document.getElementById("verify-some-bar").style.width = `${somePct}%`;

  document.getElementById("verify-never-val").textContent = `${neverPct}% (${issue.votes.never} votes)`;
  document.getElementById("verify-never-bar").style.width = `${neverPct}%`;

  document.getElementById("verify-part-val").textContent = `${partPct}% (${total}/${ESTIMATED_CLASS_SIZE} students)`;
  document.getElementById("verify-part-bar").style.width = `${partPct}%`;

  // Outcome Badge
  const outcomeBadge = document.getElementById("verify-outcome-badge");
  const isClassVerified = partPct >= 30 && (freqPct + somePct) >= 60;

  if (isClassVerified) {
    outcomeBadge.className = "text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30";
    outcomeBadge.textContent = "CLASS VERIFIED";
  } else {
    outcomeBadge.className = "text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30";
    outcomeBadge.textContent = "UNDER VERIFICATION";
  }
}

function handleVoteSubmit() {
  const enteredToken = document.getElementById("verify-token-input").value.trim();

  // Token Validation
  if (!enteredToken || enteredToken.toUpperCase() !== DEMO_TOKEN_CODE) {
    showToast("Invalid Token", "Please enter valid daily token: CV1832026", "error");
    return;
  }

  if (isTokenUsed) {
    showToast("Token Already Used", "This token has already voted today. Exactly 1 vote allowed per token.", "warning");
    return;
  }

  if (!selectedVoteOption) {
    showToast("Option Required", "Please select Frequently, Sometimes, or Never.", "warning");
    return;
  }

  const issueId = document.getElementById("verify-issue-select").value;
  const issue = issues.find(i => i.id === issueId);
  if (!issue) return;

  // Record Vote
  if (selectedVoteOption === "Frequently") issue.votes.frequently++;
  if (selectedVoteOption === "Sometimes") issue.votes.sometimes++;
  if (selectedVoteOption === "Never") issue.votes.never++;

  // Update Status Logic
  const total = issue.votes.frequently + issue.votes.sometimes + issue.votes.never;
  const partPct = Math.round((total / ESTIMATED_CLASS_SIZE) * 100);
  const expPct = Math.round(((issue.votes.frequently + issue.votes.sometimes) / total) * 100);

  if (partPct >= 30 && expPct >= 60) {
    issue.status = "CLASS VERIFIED";
  } else if (total > 0 && issue.status === "REPORTED") {
    issue.status = "UNDER VERIFICATION";
  }

  // Consume Token
  isTokenUsed = true;
  saveState();

  updateVerifyModalStats();
  refreshDashboard();

  showToast("Vote Confirmed!", `Anonymous vote (${selectedVoteOption}) counted. Token is now marked USED.`, "success");

  // Reset selected card
  selectedVoteOption = null;
  ["Frequently", "Sometimes", "Never"].forEach(opt => {
    document.getElementById(`vote-card-${opt}`).className = "cursor-pointer p-4 rounded-xl bg-slate-900/80 border-2 border-slate-700 hover:border-slate-500 transition-all text-center";
  });
}

function resetToken() {
  isTokenUsed = false;
  saveState();
  renderTokenBadge();
  showToast("Token Reset", "Daily Token CV1832026 restored to ACTIVE for demonstration.", "info");
}

function copyToken() {
  navigator.clipboard.writeText(DEMO_TOKEN_CODE);
  showToast("Copied to Clipboard", `Token ${DEMO_TOKEN_CODE} ready to paste.`, "info");
}

// -------------------------------------------------------------
// 7. Module: Issue Tracking
// -------------------------------------------------------------
function quickTrack(id) {
  document.getElementById("track-id-input").value = id;
  performTrackLookup();
}

function performTrackLookup() {
  const query = document.getElementById("track-id-input").value.trim().toUpperCase();
  const issue = issues.find(i => i.id.toUpperCase() === query);

  if (!issue) {
    showToast("Issue Not Found", `No issue found for ID "${query}". Check sample pills.`, "error");
    return;
  }

  document.getElementById("track-issue-id").textContent = issue.id;
  document.getElementById("track-category").textContent = issue.category;
  document.getElementById("track-date").textContent = issue.date;
  document.getElementById("track-title").textContent = issue.title;
  document.getElementById("track-desc").textContent = issue.description;
  document.getElementById("track-evidence").textContent = issue.evidence || "None attached";

  // Status Badge
  const statusEl = document.getElementById("track-status-badge");
  statusEl.className = "text-xs font-bold px-3 py-1 rounded-full " + getStatusBadgeClasses(issue.status);
  statusEl.textContent = issue.status;

  // Votes & Quorum calculation
  const total = issue.votes.frequently + issue.votes.sometimes + issue.votes.never;
  const freqPct = total === 0 ? 0 : Math.round((issue.votes.frequently / total) * 100);
  const partPct = Math.min(100, Math.round((total / ESTIMATED_CLASS_SIZE) * 100));

  document.getElementById("track-votes-summary").textContent = `Frequently: ${freqPct}% | Quorum: ${partPct}%`;
  document.getElementById("track-votes-bar").style.width = `${freqPct}%`;

  // Milestone Stepper update
  updateMilestoneStepper(issue.status);
}

function updateMilestoneStepper(status) {
  const s = status.toUpperCase();
  const s1 = true;
  const s2 = s.includes("VERIFICATION") || s.includes("VERIFIED") || s.includes("INVESTIGATION") || s.includes("RESOLVED");
  const s3 = s.includes("CLASS VERIFIED") || s.includes("INVESTIGATION") || s.includes("RESOLVED");
  const s4 = s.includes("RESOLVED");

  setStepState("step-1", s1, "1. Reported", "fa-check");
  setStepState("step-2", s2, "2. Verifying", "fa-hourglass");
  setStepState("step-3", s3, "3. Verified", "fa-users");
  setStepState("step-4", s4, "4. Resolved", "fa-circle-check");
}

function setStepState(stepId, isActive, text, icon) {
  const el = document.getElementById(stepId);
  if (isActive) {
    el.className = "p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold flex flex-col items-center gap-1";
    el.innerHTML = `<i class="fa-solid ${icon}"></i> ${text}`;
  } else {
    el.className = "p-2.5 rounded-xl bg-slate-800 text-slate-400 border border-slate-700 font-bold flex flex-col items-center gap-1";
    el.innerHTML = `<i class="fa-regular fa-circle text-slate-500"></i> ${text}`;
  }
}

function getStatusBadgeClasses(status) {
  const s = status.toUpperCase();
  if (s.includes("CLASS VERIFIED")) return "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30";
  if (s.includes("RESOLVED")) return "bg-blue-500/20 text-blue-300 border border-blue-500/30";
  if (s.includes("UNDER VERIFICATION")) return "bg-amber-500/20 text-amber-300 border border-amber-500/30";
  if (s.includes("REOPENED")) return "bg-rose-500/20 text-rose-300 border border-rose-500/30";
  if (s.includes("UNDER INVESTIGATION")) return "bg-purple-500/20 text-purple-300 border border-purple-500/30";
  return "bg-slate-700 text-slate-300 border border-slate-600";
}

function copyTrackedId() {
  const id = document.getElementById("track-issue-id").textContent;
  navigator.clipboard.writeText(id);
  showToast("Copied", `Issue ID ${id} copied to clipboard.`, "info");
}

// -------------------------------------------------------------
// 8. Module: Re-Verification
// -------------------------------------------------------------
function populateReverifyModalIssues() {
  const select = document.getElementById("reverify-issue-select");
  select.innerHTML = issues.map(i => `<option value="${i.id}">[${i.id}] (${i.status}) ${i.title}</option>`).join("");
}

function selectReverifyOption(opt) {
  selectedReverifyOption = opt;
  ["Resolved", "Partially", "Still"].forEach(k => {
    const card = document.getElementById(`reverify-card-${k}`);
    if ((k === "Resolved" && opt === "Resolved") ||
        (k === "Partially" && opt === "Partially Resolved") ||
        (k === "Still" && opt === "Still Facing Problem")) {
      if (k === "Resolved") card.className = "cursor-pointer p-3.5 rounded-xl card-selected-emerald border-2 text-center";
      if (k === "Partially") card.className = "cursor-pointer p-3.5 rounded-xl card-selected-amber border-2 text-center";
      if (k === "Still") card.className = "cursor-pointer p-3.5 rounded-xl card-selected-rose border-2 text-center";
    } else {
      card.className = "cursor-pointer p-3.5 rounded-xl bg-slate-900/80 border-2 border-slate-700 hover:border-slate-500 transition-all text-center";
    }
  });
}

function handleReverifySubmit() {
  if (!selectedReverifyOption) {
    showToast("Feedback Required", "Please select a feedback option.", "warning");
    return;
  }

  const issueId = document.getElementById("reverify-issue-select").value;
  const issue = issues.find(i => i.id === issueId);
  if (!issue) return;

  if (selectedReverifyOption === "Resolved") {
    issue.reverify.resolved++;
    showToast("Feedback Recorded", `Confirmed resolution for ${issueId}.`, "success");
  } else if (selectedReverifyOption === "Partially Resolved") {
    issue.reverify.partially++;
    showToast("Feedback Recorded", `Partially resolved feedback recorded for ${issueId}.`, "info");
  } else if (selectedReverifyOption === "Still Facing Problem") {
    issue.reverify.stillFacing++;
    // Auto-reopen escalation trigger
    if (issue.reverify.stillFacing >= 1) {
      issue.status = "REOPENED";
      showToast("Auto-Escalated to REOPENED", `Issue ${issueId} escalated due to ongoing student complaints.`, "error");
    }
  }

  saveState();
  closeModal("modal-reverify");
  refreshDashboard();

  selectedReverifyOption = null;
  ["Resolved", "Partially", "Still"].forEach(k => {
    document.getElementById(`reverify-card-${k}`).className = "cursor-pointer p-3.5 rounded-xl bg-slate-900/80 border-2 border-slate-700 text-center";
  });
}

// -------------------------------------------------------------
// 9. Administrator Dashboard
// -------------------------------------------------------------
function renderAdminDashboard() {
  let reported = 0, verified = 0, resolved = 0;
  issues.forEach(i => {
    const s = i.status.toUpperCase();
    if (s.includes("REPORTED")) reported++;
    if (s.includes("CLASS VERIFIED")) verified++;
    if (s.includes("RESOLVED")) resolved++;
  });

  document.getElementById("admin-stat-total").textContent = issues.length;
  document.getElementById("admin-stat-reported").textContent = reported;
  document.getElementById("admin-stat-verified").textContent = verified;
  document.getElementById("admin-stat-resolved").textContent = resolved;

  renderAdminTable();
}

function renderAdminTable() {
  const tbody = document.getElementById("table-admin-body");
  const catFilter = document.getElementById("admin-filter-cat").value;
  const statusFilter = document.getElementById("admin-filter-status").value;

  const filtered = issues.filter(i => {
    if (catFilter !== "ALL" && i.category !== catFilter) return false;
    if (statusFilter !== "ALL" && i.status !== statusFilter) return false;
    return true;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="py-8 text-center text-slate-500">No issues match filters.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(issue => {
    const total = issue.votes.frequently + issue.votes.sometimes + issue.votes.never;
    const expPct = total === 0 ? 0 : Math.round(((issue.votes.frequently + issue.votes.sometimes) / total) * 100);
    const isSelected = issue.id === currentAdminSelectedId;

    return `
      <tr onclick="selectAdminRow('${issue.id}')" class="transition-colors cursor-pointer ${isSelected ? 'bg-amber-950/40 border-l-4 border-amber-500' : 'hover:bg-slate-700/40'}">
        <td class="py-3 px-4 font-mono font-bold text-amber-400">${issue.id}</td>
        <td class="py-3 px-4 text-slate-300">${issue.category}</td>
        <td class="py-3 px-4 font-semibold text-white max-w-xs truncate">${issue.title}</td>
        <td class="py-3 px-4 text-slate-400">${issue.date}</td>
        <td class="py-3 px-4 text-slate-300">${expPct}% (${total} votes)</td>
        <td class="py-3 px-4">${renderStatusBadgeHTML(issue.status)}</td>
        <td class="py-3 px-4 text-right">
          <input type="radio" name="admin-selected-radio" ${isSelected ? 'checked' : ''} class="accent-amber-500">
        </td>
      </tr>
    `;
  }).join("");
}

function selectAdminRow(issueId) {
  currentAdminSelectedId = issueId;
  const issue = issues.find(i => i.id === issueId);
  if (!issue) return;

  document.getElementById("admin-selected-id").textContent = `${issue.id} (${issue.status})`;
  document.getElementById("btn-admin-investigate").disabled = false;
  document.getElementById("btn-admin-resolve").disabled = false;
  document.getElementById("btn-admin-reopen").disabled = false;

  renderAdminTable();
}

function adminApplyStatus(newStatus) {
  if (!currentAdminSelectedId) return;
  const issue = issues.find(i => i.id === currentAdminSelectedId);
  if (!issue) return;

  issue.status = newStatus;
  saveState();
  renderAdminDashboard();
  showToast("Status Updated", `Issue ${issue.id} updated to ${newStatus}.`, "success");
}

// -------------------------------------------------------------
// 10. Sleek Toast Notification Hub
// -------------------------------------------------------------
function showToast(title, message, type = "info") {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;

  const icons = {
    success: "fa-solid fa-circle-check text-emerald-400",
    error: "fa-solid fa-circle-xmark text-rose-400",
    warning: "fa-solid fa-triangle-exclamation text-amber-400",
    info: "fa-solid fa-circle-info text-blue-400"
  };

  toast.innerHTML = `
    <i class="${icons[type] || icons.info} text-lg mt-0.5"></i>
    <div class="flex-1">
      <h5 class="text-xs font-bold uppercase tracking-wider">${title}</h5>
      <p class="text-xs text-slate-200 mt-0.5">${message}</p>
    </div>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(50px)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Global initialization
document.addEventListener("DOMContentLoaded", () => {
  refreshDashboard();
});
