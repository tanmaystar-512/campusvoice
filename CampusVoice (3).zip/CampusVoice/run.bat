@echo off
title CampusVoice - Anonymous Student Issue Reporting & Verification
echo ====================================================
echo    CampusVoice - College Prototype Launcher
echo    Lead: Yash Raj (24EARAD183)
echo    Arya College of Engineering & IT (RTU Kota)
echo ====================================================
echo.
echo Compiling source files...
if not exist out mkdir out
javac -d out src\campusvoice\model\*.java src\campusvoice\utils\*.java src\campusvoice\ui\*.java src\campusvoice\Main.java src\campusvoice\TestSuite.java

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Compilation failed.
    pause
    exit /b %ERRORLEVEL%
)

echo Compilation successful! Launching CampusVoice UI...
start javaw -cp out campusvoice.Main
exit
