@echo off
title CampusVoice Web Application Launcher
echo ====================================================
echo    CampusVoice - HTML/CSS/JS Web Launcher
echo    Lead: Yash Raj (24EARAD183)
echo    Arya College of Engineering & IT (RTU Kota)
echo ====================================================
echo.
echo Launching CampusVoice Web UI...

REM Try launching through embedded Java web server if javac/java is available
if exist out (
    start javaw -cp out campusvoice.WebServer
) else (
    REM Direct browser launch fallback
    start "" "web\index.html"
)

echo.
echo Application launched in your default web browser!
timeout /t 3 >nul
exit
